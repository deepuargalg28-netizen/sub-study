# Build audit / changes

- Removed the custom debug keystore reference: the archive did not contain `debug.keystore`, so this custom debug signing setup could prevent debug builds. The project now uses Gradle's normal debug signing.
- Made release signing conditional on the signing environment being configured, rather than assuming an upload keystore is present.
- Added a GitHub Actions workflow to build and upload the installable debug APK as an artifact.
- Added build and installation steps in the README.

## Not verified in this environment
A full Android build was not run: this environment has no Android SDK installed, no Gradle executable/wrapper JAR included in the upload, and network access is unavailable to fetch build dependencies. The Kotlin source still requires an actual Android Gradle build to confirm compile/runtime correctness.
