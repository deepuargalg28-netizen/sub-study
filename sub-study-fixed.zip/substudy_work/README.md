# Sub Study (Android)

LKG zero-touch learning app with Hindi-English voice guidance, lessons, activities, parent controls and local progress.

## Build an installable APK

### Quick build on Android Studio
1. Open this project in Android Studio.
2. Let Gradle sync finish and install the Android SDK platform/build tools required by the project.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the generated debug APK from `app/build/outputs/apk/debug/app-debug.apk`.

The debug build uses Android's standard debug signing, so no upload keystore is needed.

### Build/download from GitHub Actions
1. Upload this project to a GitHub repository.
2. Open **Actions** and select **Build Sub Study APK**.
3. Run the workflow with **Run workflow** (or push to `main`/`master`).
4. Once completed, download the **Sub-Study-debug-APK** artifact from that run. Unzip it and install `app-debug.apk` on your Android phone. Android may ask you to allow installing apps from that source.

## Notes
- Release APK signing requires a keystore and the `KEYSTORE_PATH`, `STORE_PASSWORD`, and `KEY_PASSWORD` environment variables.
- The debug APK is intended for testing and direct installation, not Play Store distribution.
