package com.example

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.model.SubjectId
import com.example.ui.components.ClassroomBackground
import com.example.ui.components.ParentGateDialog
import com.example.ui.screens.FunActivityKind
import com.example.ui.screens.GamesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LearnHubScreen
import com.example.ui.screens.LessonEngineScreen
import com.example.ui.screens.ParentSettingsScreen
import com.example.ui.screens.ProgressScreen
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.InkNavy
import com.example.ui.theme.MathsBlueSoft
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SubStudyTheme
import com.example.viewmodel.SubStudyViewModel

object SubStudyRoutes {
    const val HOME = "home"
    const val LEARN = "learn"
    const val GAMES = "games"
    const val PROGRESS = "progress"
    const val LESSON = "lesson/{topicId}"
    const val PARENT_SETTINGS = "parent_settings"

    fun lessonRoute(topicId: String) = "lesson/$topicId"
}

private data class BottomTabItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private enum class GatePurpose {
    OPEN_PARENT_SETTINGS,
    EXIT_LESSON,
    EXIT_APP,
    UNLOCK_SAFE_BREAK
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SubStudyTheme {
                SubStudyRootApp()
            }
        }
    }
}

@Composable
fun SubStudyRootApp(
    viewModel: SubStudyViewModel = viewModel()
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: SubStudyRoutes.HOME
    val context = LocalContext.current

    val profile by viewModel.profile.collectAsStateWithLifecycle()
    val parentSettings by viewModel.parentSettings.collectAsStateWithLifecycle()
    val topicProgressList by viewModel.topicProgressList.collectAsStateWithLifecycle()
    val recentSessions by viewModel.recentSessions.collectAsStateWithLifecycle()
    val todayProgressFraction by viewModel.todayProgressFraction.collectAsStateWithLifecycle()
    val recommendedTopic by viewModel.recommendedTopic.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.isSpeaking.collectAsStateWithLifecycle()
    val isListening by viewModel.isListening.collectAsStateWithLifecycle()
    val teacherCaption by viewModel.teacherCaption.collectAsStateWithLifecycle()
    val autoplayCountdown by viewModel.homeAutoplayCountdown.collectAsStateWithLifecycle()
    val isAutoplayPaused by viewModel.homeAutoplayPaused.collectAsStateWithLifecycle()
    val isSessionLimitReached by viewModel.isSessionLimitReached.collectAsStateWithLifecycle()
    val lessonState by viewModel.lessonState.collectAsStateWithLifecycle()
    val activeRhymeLineIndex by viewModel.activeRhymeLineIndex.collectAsStateWithLifecycle()

    var selectedLearnSubject by remember { mutableStateOf<SubjectId?>(null) }
    var selectedFunActivity by remember { mutableStateOf(FunActivityKind.MEMORY_GAMES) }
    var activeGatePurpose by remember { mutableStateOf<GatePurpose?>(null) }

    val navigateToLesson: (String) -> Unit = { topicId ->
        viewModel.pauseHomeAutoplay()
        navController.navigate(SubStudyRoutes.lessonRoute(topicId)) {
            launchSingleTop = true
        }
    }

    val navigateToTab: (String) -> Unit = { route ->
        viewModel.pauseHomeAutoplay()
        viewModel.playTapSound()
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    LaunchedEffect(currentRoute) {
        viewModel.setParentAreaActive(currentRoute == SubStudyRoutes.PARENT_SETTINGS)
        if (currentRoute == SubStudyRoutes.HOME) {
            viewModel.onHomeEntered(onAutoLaunchLesson = navigateToLesson)
        } else {
            viewModel.pauseHomeAutoplay()
        }
    }

    // Child Exit Protection on Home Screen
    BackHandler(enabled = currentRoute == SubStudyRoutes.HOME && parentSettings.exitProtectionEnabled) {
        activeGatePurpose = GatePurpose.EXIT_APP
    }

    val topLevelTabs = remember {
        listOf(
            BottomTabItem(SubStudyRoutes.HOME, "Home", Icons.Rounded.Home, Icons.Outlined.Home),
            BottomTabItem(SubStudyRoutes.LEARN, "Learn", Icons.Rounded.MenuBook, Icons.Outlined.MenuBook),
            BottomTabItem(SubStudyRoutes.GAMES, "Games", Icons.Rounded.SportsEsports, Icons.Outlined.SportsEsports),
            BottomTabItem(SubStudyRoutes.PROGRESS, "Progress", Icons.Rounded.BarChart, Icons.Outlined.BarChart)
        )
    }

    val showNavChrome = currentRoute in topLevelTabs.map { it.route }

    ClassroomBackground {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isWideScreen = maxWidth >= 680.dp

            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    if (showNavChrome && !isWideScreen) {
                        NavigationBar(
                            containerColor = PureWhite.copy(alpha = 0.96f),
                            tonalElevation = 8.dp,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            topLevelTabs.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateToTab(tab.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = tab.label,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = BrandBlue,
                                        selectedTextColor = BrandBlue,
                                        indicatorColor = MathsBlueSoft,
                                        unselectedIconColor = SlateMuted,
                                        unselectedTextColor = SlateMuted
                                    ),
                                    modifier = Modifier.testTag("nav_tab_${tab.route}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (showNavChrome && isWideScreen) {
                        NavigationRail(
                            containerColor = PureWhite.copy(alpha = 0.94f),
                            modifier = Modifier
                                .fillMaxHeight()
                                .windowInsetsPadding(WindowInsets.statusBars)
                        ) {
                            topLevelTabs.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateToTab(tab.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = BrandBlue,
                                        selectedTextColor = BrandBlue,
                                        indicatorColor = MathsBlueSoft,
                                        unselectedIconColor = SlateMuted,
                                        unselectedTextColor = SlateMuted
                                    )
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                        NavHost(
                            navController = navController,
                            startDestination = SubStudyRoutes.HOME
                        ) {
                            composable(SubStudyRoutes.HOME) {
                                HomeScreen(
                                    profile = profile,
                                    recommendedTopic = recommendedTopic,
                                    topicProgressList = topicProgressList,
                                    todayProgressFraction = todayProgressFraction,
                                    isSpeaking = isSpeaking,
                                    teacherCaption = teacherCaption,
                                    autoplayCountdown = autoplayCountdown,
                                    isAutoplayPaused = isAutoplayPaused,
                                    isSessionLimitReached = isSessionLimitReached,
                                    onContinueLearning = { topicId ->
                                        viewModel.playTapSound()
                                        navigateToLesson(topicId)
                                    },
                                    onToggleAutoplayPause = {
                                        viewModel.toggleHomeAutoplayPause(navigateToLesson)
                                    },
                                    onSubjectSelected = { subjectId ->
                                        viewModel.playTapSound()
                                        selectedLearnSubject = subjectId
                                        viewModel.speakMessage("Chalo ${subjectId.title} seekhte hain!")
                                        navigateToTab(SubStudyRoutes.LEARN)
                                    },
                                    onFunActivitySelected = { activity ->
                                        viewModel.playTapSound()
                                        selectedFunActivity = activity
                                        navigateToTab(SubStudyRoutes.GAMES)
                                    },
                                    onOpenParentSettings = {
                                        viewModel.pauseHomeAutoplay()
                                        activeGatePurpose = GatePurpose.OPEN_PARENT_SETTINGS
                                    },
                                    onTapTeacherAvatar = {
                                        viewModel.speakMessage(
                                            "Hello ${profile.childName}! Main Miss Tara hoon! Chalo saath mein LKG seekhein!"
                                        )
                                    }
                                )
                            }

                            composable(SubStudyRoutes.LEARN) {
                                LearnHubScreen(
                                    selectedSubject = selectedLearnSubject,
                                    topicProgressList = topicProgressList,
                                    onSelectSubjectFilter = { subj ->
                                        viewModel.playTapSound()
                                        selectedLearnSubject = subj
                                    },
                                    onStartTopic = { topicId ->
                                        viewModel.playTapSound()
                                        navigateToLesson(topicId)
                                    }
                                )
                            }

                            composable(SubStudyRoutes.GAMES) {
                                GamesScreen(
                                    initialActivity = selectedFunActivity,
                                    totalStars = profile.totalStars,
                                    activeRhymeLineIndex = activeRhymeLineIndex,
                                    onSpeak = { msg -> viewModel.speakMessage(msg) },
                                    onTapSound = { viewModel.playTapSound() },
                                    onPlayRhyme = { lyrics, notes, title, onDone ->
                                        viewModel.playRhyme(lyrics, notes, title, onDone)
                                    },
                                    onStopRhyme = { viewModel.stopRhyme() },
                                    onAwardStars = { stars, reason ->
                                        viewModel.awardGameStars(stars, reason)
                                    }
                                )
                            }

                            composable(SubStudyRoutes.PROGRESS) {
                                ProgressScreen(
                                    profile = profile,
                                    topicProgressList = topicProgressList,
                                    recentSessions = recentSessions,
                                    todayProgressFraction = todayProgressFraction,
                                    onOpenParentControls = {
                                        activeGatePurpose = GatePurpose.OPEN_PARENT_SETTINGS
                                    }
                                )
                            }

                            composable(
                                route = SubStudyRoutes.LESSON,
                                arguments = listOf(navArgument("topicId") { type = NavType.StringType })
                            ) { entry ->
                                val topicId = entry.arguments?.getString("topicId") ?: recommendedTopic.id
                                LaunchedEffect(topicId) {
                                    viewModel.startLesson(topicId)
                                }
                                LessonEngineScreen(
                                    state = lessonState,
                                    isSpeaking = isSpeaking,
                                    isListening = isListening,
                                    teacherCaption = teacherCaption,
                                    exitProtectionEnabled = parentSettings.exitProtectionEnabled,
                                    onRequestExitWithParentGate = {
                                        activeGatePurpose = GatePurpose.EXIT_LESSON
                                    },
                                    onExitLessonDirect = {
                                        viewModel.stopLesson()
                                        navController.popBackStack()
                                    },
                                    onTogglePause = { viewModel.toggleLessonPause() },
                                    onRepeatVoice = { viewModel.speakMessage(teacherCaption) },
                                    onPulseInteractive = { viewModel.triggerInteractivePulse() },
                                    onSkipNextItem = { viewModel.skipToNextExplainItem() },
                                    onSelectOption = { optId -> viewModel.submitAnswerOption(optId) },
                                    onStartVoiceAnswer = { viewModel.startVoiceAnswerForQuestion() },
                                    onDoneDrawing = { viewModel.completeDrawingActivity() },
                                    onStartNextTopicNow = {
                                        val nextId = com.example.data.model.LkgCurriculumRepository
                                            .nextTopicAfter(lessonState.topic.id).id
                                        viewModel.startLesson(nextId)
                                    },
                                    onUnlockBreakRequest = {
                                        activeGatePurpose = GatePurpose.UNLOCK_SAFE_BREAK
                                    }
                                )
                            }

                            composable(SubStudyRoutes.PARENT_SETTINGS) {
                                ParentSettingsScreen(
                                    profile = profile,
                                    settings = parentSettings,
                                    topicProgressList = topicProgressList,
                                    onBack = { navController.popBackStack() },
                                    onUpdateProfile = viewModel::updateChildProfile,
                                    onSetSessionLimitMinutes = viewModel::setSessionLimitMinutes,
                                    onResetTodayTimer = viewModel::resetTodayTimer,
                                    onSetAutoplayEnabled = viewModel::setAutoplayEnabled,
                                    onSetVoiceTeacherEnabled = viewModel::setVoiceTeacherEnabled,
                                    onSetSoundEffectsEnabled = viewModel::setSoundEffectsEnabled,
                                    onSetSpeechRate = viewModel::setSpeechRate,
                                    onSetExitProtectionEnabled = viewModel::setExitProtectionEnabled,
                                    onUpdatePin = viewModel::updateParentPin,
                                    onResetProgress = viewModel::resetAllProgress
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Parent Gate Modal (protects Parent Settings, Lesson Exit, App Exit, and Safe Break Unlock)
    activeGatePurpose?.let { purpose ->
        val (title, subtitle) = when (purpose) {
            GatePurpose.OPEN_PARENT_SETTINGS ->
                "Parent Settings" to "Parents only area for screen time, voice controls, and progress reports."
            GatePurpose.EXIT_LESSON ->
                "Exit Learning Lesson?" to "Exit protection is active so kids stay focused on learning."
            GatePurpose.EXIT_APP ->
                "Leave Sub Study?" to "Exit protection prevents children from accidentally closing the app."
            GatePurpose.UNLOCK_SAFE_BREAK ->
                "Extend Learning Time" to "Unlock to reset today's session timer and continue."
        }
        ParentGateDialog(
            title = title,
            subtitle = subtitle,
            expectedPin = parentSettings.parentPin,
            onDismiss = { activeGatePurpose = null },
            onUnlocked = {
                activeGatePurpose = null
                when (purpose) {
                    GatePurpose.OPEN_PARENT_SETTINGS -> {
                        navController.navigate(SubStudyRoutes.PARENT_SETTINGS) {
                            launchSingleTop = true
                        }
                    }
                    GatePurpose.EXIT_LESSON -> {
                        viewModel.stopLesson()
                        navController.popBackStack()
                    }
                    GatePurpose.EXIT_APP -> {
                        (context as? Activity)?.finish()
                    }
                    GatePurpose.UNLOCK_SAFE_BREAK -> {
                        viewModel.unlockFromBreakScreen()
                        viewModel.startLesson(lessonState.topic.id)
                    }
                }
            }
        )
    }
}
