package com.example.audio

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class VoiceTeacherEngine(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var voiceEnabled = true
    private var sfxEnabled = true
    private var speechRate = 0.92f

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _currentCaption = MutableStateFlow("Hello Little Star! Aaj hum seekhenge!")
    val currentCaption: StateFlow<String> = _currentCaption.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _activeRhymeLineIndex = MutableStateFlow(-1)
    val activeRhymeLineIndex: StateFlow<Int> = _activeRhymeLineIndex.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var pendingUtteranceCallbacks = mutableMapOf<String, () -> Unit>()
    private var fallbackTimerJob: Job? = null
    private var rhymeJob: Job? = null
    private var sfxJob: Job? = null

    init {
        initTts()
    }

    private fun initTts() {
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val engine = tts ?: return@TextToSpeech
                    val hiIn = Locale("hi", "IN")
                    val enIn = Locale("en", "IN")
                    val res = when {
                        engine.isLanguageAvailable(hiIn) >= TextToSpeech.LANG_AVAILABLE -> {
                            engine.language = hiIn
                            TextToSpeech.LANG_AVAILABLE
                        }
                        engine.isLanguageAvailable(enIn) >= TextToSpeech.LANG_AVAILABLE -> {
                            engine.language = enIn
                            TextToSpeech.LANG_AVAILABLE
                        }
                        else -> {
                            engine.setLanguage(Locale.US)
                        }
                    }
                    engine.setPitch(1.12f)
                    engine.setSpeechRate(speechRate)
                    engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            scope.launch { _isSpeaking.value = true }
                        }

                        override fun onDone(utteranceId: String?) {
                            scope.launch {
                                _isSpeaking.value = false
                                fallbackTimerJob?.cancel()
                                utteranceId?.let { id ->
                                    pendingUtteranceCallbacks.remove(id)?.invoke()
                                }
                            }
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            onDone(utteranceId)
                        }

                        override fun onError(utteranceId: String?, errorCode: Int) {
                            onDone(utteranceId)
                        }
                    })
                    ttsReady = res >= TextToSpeech.LANG_AVAILABLE || engine.language != null
                }
            }
        } catch (_: Exception) {
            ttsReady = false
        }
    }

    fun updateSettings(
        voiceEnabled: Boolean,
        sfxEnabled: Boolean,
        speechRate: Float
    ) {
        this.voiceEnabled = voiceEnabled
        this.sfxEnabled = sfxEnabled
        this.speechRate = speechRate
        try {
            tts?.setSpeechRate(speechRate)
        } catch (_: Exception) {
        }
        if (!voiceEnabled) {
            stopSpeaking()
        }
    }

    fun speak(
        text: String,
        caption: String = text,
        onFinished: (() -> Unit)? = null
    ) {
        _currentCaption.value = caption
        fallbackTimerJob?.cancel()

        val estimatedDurationMs = ((text.length * 52L) / speechRate.coerceAtLeast(0.65f)).toLong()
            .coerceIn(1800L, 8500L)

        if (!voiceEnabled || !ttsReady || tts == null) {
            _isSpeaking.value = true
            fallbackTimerJob = scope.launch {
                delay(estimatedDurationMs)
                _isSpeaking.value = false
                onFinished?.invoke()
            }
            return
        }

        val utteranceId = UUID.randomUUID().toString()
        if (onFinished != null) {
            pendingUtteranceCallbacks.clear()
            pendingUtteranceCallbacks[utteranceId] = onFinished
        }

        try {
            val params = Bundle()
            _isSpeaking.value = true
            val result = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
            if (result != TextToSpeech.SUCCESS) {
                fallbackTimerJob = scope.launch {
                    delay(estimatedDurationMs)
                    _isSpeaking.value = false
                    pendingUtteranceCallbacks.remove(utteranceId)?.invoke()
                }
            } else {
                // Safety guard in case TTS engine silently drops utterance callback
                fallbackTimerJob = scope.launch {
                    delay(estimatedDurationMs + 3500L)
                    if (pendingUtteranceCallbacks.containsKey(utteranceId)) {
                        _isSpeaking.value = false
                        pendingUtteranceCallbacks.remove(utteranceId)?.invoke()
                    }
                }
            }
        } catch (_: Exception) {
            fallbackTimerJob = scope.launch {
                delay(estimatedDurationMs)
                _isSpeaking.value = false
                onFinished?.invoke()
            }
        }
    }

    fun stopSpeaking() {
        fallbackTimerJob?.cancel()
        pendingUtteranceCallbacks.clear()
        _isSpeaking.value = false
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
    }

    fun playTapPop() {
        if (!sfxEnabled) return
        playTones(listOf(660f to 65, 880f to 75), volume = 0.28f)
    }

    fun playStarDing() {
        if (!sfxEnabled) return
        playTones(listOf(784f to 110, 1046.5f to 220), volume = 0.35f)
    }

    fun playCelebrateFanfare() {
        if (!sfxEnabled) return
        playTones(
            listOf(
                523.25f to 110,
                659.25f to 110,
                783.99f to 120,
                1046.50f to 340
            ),
            volume = 0.42f
        )
    }

    fun playGentleTryAgain() {
        if (!sfxEnabled) return
        playTones(listOf(392.0f to 140, 349.23f to 200), volume = 0.25f)
    }

    fun playRhymeMelody(
        notes: List<Pair<Float, Int>>,
        lineCount: Int,
        onComplete: () -> Unit
    ) {
        stopRhyme()
        if (notes.isEmpty()) {
            onComplete()
            return
        }
        rhymeJob = scope.launch(Dispatchers.Default) {
            val totalNotes = notes.size
            notes.forEachIndexed { idx, (freq, durMs) ->
                if (!isActive) return@launch
                val lineIdx = ((idx * lineCount) / totalNotes).coerceIn(0, (lineCount - 1).coerceAtLeast(0))
                launch(Dispatchers.Main) {
                    _activeRhymeLineIndex.value = lineIdx
                }
                if (sfxEnabled) {
                    playSingleToneBlocking(freq, durMs, volume = 0.35f)
                } else {
                    delay(durMs.toLong())
                }
            }
            launch(Dispatchers.Main) {
                _activeRhymeLineIndex.value = -1
                onComplete()
            }
        }
    }

    fun stopRhyme() {
        rhymeJob?.cancel()
        rhymeJob = null
        _activeRhymeLineIndex.value = -1
    }

    private fun playTones(tones: List<Pair<Float, Int>>, volume: Float) {
        sfxJob?.cancel()
        sfxJob = scope.launch(Dispatchers.IO) {
            for ((freq, dur) in tones) {
                if (!isActive) break
                playSingleToneBlocking(freq, dur, volume)
            }
        }
    }

    private fun playSingleToneBlocking(freqHz: Float, durationMs: Int, volume: Float) {
        val sampleRate = 22050
        val count = ((sampleRate * durationMs) / 1000).coerceAtLeast(256)
        val buffer = ShortArray(count)
        for (i in 0 until count) {
            val t = i.toFloat() / sampleRate
            val env = exp(-3.5 * i / count).toFloat()
            val attack = if (i < 120) i / 120f else 1f
            val wave = 0.75f * sin(2.0 * PI * freqHz * t).toFloat() +
                0.25f * sin(4.0 * PI * freqHz * t).toFloat()
            buffer[i] = (wave * env * attack * volume * Short.MAX_VALUE).toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        var track: AudioTrack? = null
        try {
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(buffer, 0, buffer.size)
            track.play()
            Thread.sleep(durationMs.toLong())
        } catch (_: Exception) {
        } finally {
            try {
                track?.stop()
                track?.release()
            } catch (_: Exception) {
            }
        }
    }

    fun startListening(
        onResult: (String) -> Unit,
        onUnavailableOrError: (String) -> Unit
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onUnavailableOrError("Tap the big picture below to answer!")
            return
        }
        Handler(Looper.getMainLooper()).post {
            try {
                stopSpeaking()
                speechRecognizer?.destroy()
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
                speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _isListening.value = true
                    }

                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        _isListening.value = false
                    }

                    override fun onError(error: Int) {
                        _isListening.value = false
                        onUnavailableOrError("Awaaz clear nahi aayi! Picture par tap karo!")
                    }

                    override fun onResults(results: Bundle?) {
                        _isListening.value = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val best = matches?.firstOrNull().orEmpty()
                        if (best.isNotBlank()) {
                            onResult(best)
                        } else {
                            onUnavailableOrError("Phir se bolo ya picture par tap karo!")
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }
                _isListening.value = true
                speechRecognizer?.startListening(intent)
            } catch (_: Exception) {
                _isListening.value = false
                onUnavailableOrError("Mic abhi ready nahi hai! Picture par tap karo!")
            }
        }
    }

    fun stopListening() {
        _isListening.value = false
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (_: Exception) {
        }
    }

    fun release() {
        stopSpeaking()
        stopRhyme()
        stopListening()
        sfxJob?.cancel()
        try {
            tts?.shutdown()
        } catch (_: Exception) {
        }
        scope.cancel()
    }
}
