package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.parentSettingsStore: DataStore<Preferences> by preferencesDataStore(
    name = "sub_study_parent_settings"
)

data class ParentSettings(
    val parentPin: String = "1234",
    val sessionLimitMinutes: Int = 20, // 0 = Unlimited
    val todayElapsedSeconds: Int = 0,
    val lastUsageDateKey: String = "",
    val autoplayEnabled: Boolean = true,
    val voiceTeacherEnabled: Boolean = true,
    val soundEffectsEnabled: Boolean = true,
    val speechRate: Float = 0.92f,
    val exitProtectionEnabled: Boolean = true
)

class ParentSettingsDataStore(private val context: Context) {

    private object Keys {
        val PARENT_PIN = stringPreferencesKey("parent_pin")
        val SESSION_LIMIT_MIN = intPreferencesKey("session_limit_min")
        val TODAY_ELAPSED_SEC = intPreferencesKey("today_elapsed_sec")
        val LAST_USAGE_DATE = stringPreferencesKey("last_usage_date")
        val AUTOPLAY_ENABLED = booleanPreferencesKey("autoplay_enabled")
        val VOICE_TEACHER_ENABLED = booleanPreferencesKey("voice_teacher_enabled")
        val SOUND_EFFECTS_ENABLED = booleanPreferencesKey("sound_effects_enabled")
        val SPEECH_RATE = floatPreferencesKey("speech_rate")
        val EXIT_PROTECTION = booleanPreferencesKey("exit_protection")
    }

    val settingsFlow: Flow<ParentSettings> = context.parentSettingsStore.data.map { prefs ->
        ParentSettings(
            parentPin = prefs[Keys.PARENT_PIN] ?: "1234",
            sessionLimitMinutes = prefs[Keys.SESSION_LIMIT_MIN] ?: 20,
            todayElapsedSeconds = prefs[Keys.TODAY_ELAPSED_SEC] ?: 0,
            lastUsageDateKey = prefs[Keys.LAST_USAGE_DATE] ?: "",
            autoplayEnabled = prefs[Keys.AUTOPLAY_ENABLED] ?: true,
            voiceTeacherEnabled = prefs[Keys.VOICE_TEACHER_ENABLED] ?: true,
            soundEffectsEnabled = prefs[Keys.SOUND_EFFECTS_ENABLED] ?: true,
            speechRate = prefs[Keys.SPEECH_RATE] ?: 0.92f,
            exitProtectionEnabled = prefs[Keys.EXIT_PROTECTION] ?: true
        )
    }

    suspend fun updatePin(newPin: String) {
        context.parentSettingsStore.edit { it[Keys.PARENT_PIN] = newPin }
    }

    suspend fun setSessionLimitMinutes(minutes: Int) {
        context.parentSettingsStore.edit { it[Keys.SESSION_LIMIT_MIN] = minutes }
    }

    suspend fun setAutoplayEnabled(enabled: Boolean) {
        context.parentSettingsStore.edit { it[Keys.AUTOPLAY_ENABLED] = enabled }
    }

    suspend fun setVoiceTeacherEnabled(enabled: Boolean) {
        context.parentSettingsStore.edit { it[Keys.VOICE_TEACHER_ENABLED] = enabled }
    }

    suspend fun setSoundEffectsEnabled(enabled: Boolean) {
        context.parentSettingsStore.edit { it[Keys.SOUND_EFFECTS_ENABLED] = enabled }
    }

    suspend fun setSpeechRate(rate: Float) {
        context.parentSettingsStore.edit { it[Keys.SPEECH_RATE] = rate.coerceIn(0.65f, 1.25f) }
    }

    suspend fun setExitProtectionEnabled(enabled: Boolean) {
        context.parentSettingsStore.edit { it[Keys.EXIT_PROTECTION] = enabled }
    }

    suspend fun addElapsedSeconds(deltaSeconds: Int, todayKey: String) {
        context.parentSettingsStore.edit { prefs ->
            val storedDate = prefs[Keys.LAST_USAGE_DATE] ?: ""
            val current = if (storedDate == todayKey) (prefs[Keys.TODAY_ELAPSED_SEC] ?: 0) else 0
            prefs[Keys.LAST_USAGE_DATE] = todayKey
            prefs[Keys.TODAY_ELAPSED_SEC] = current + deltaSeconds
        }
    }

    suspend fun resetTodayTimer(todayKey: String) {
        context.parentSettingsStore.edit { prefs ->
            prefs[Keys.LAST_USAGE_DATE] = todayKey
            prefs[Keys.TODAY_ELAPSED_SEC] = 0
        }
    }
}
