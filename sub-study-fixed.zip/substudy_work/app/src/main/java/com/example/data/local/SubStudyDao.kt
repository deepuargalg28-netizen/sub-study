package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SubStudyDao {
    @Query("SELECT * FROM child_profile WHERE id = 1")
    fun observeProfile(): Flow<ChildProfileEntity?>

    @Query("SELECT * FROM child_profile WHERE id = 1")
    suspend fun getProfileOnce(): ChildProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: ChildProfileEntity)

    @Query("SELECT * FROM topic_progress")
    fun observeAllTopicProgress(): Flow<List<TopicProgressEntity>>

    @Query("SELECT * FROM topic_progress WHERE topicId = :topicId")
    suspend fun getTopicProgressOnce(topicId: String): TopicProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTopicProgress(progress: TopicProgressEntity)

    @Query("SELECT * FROM session_logs ORDER BY timestamp DESC LIMIT 30")
    fun observeRecentSessions(): Flow<List<SessionLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessionLog(log: SessionLogEntity)

    @Query("DELETE FROM topic_progress")
    suspend fun clearTopicProgress()

    @Query("DELETE FROM session_logs")
    suspend fun clearSessionLogs()
}
