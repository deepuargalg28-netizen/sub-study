package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ChildProfileEntity::class,
        TopicProgressEntity::class,
        SessionLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SubStudyDatabase : RoomDatabase() {
    abstract fun subStudyDao(): SubStudyDao

    companion object {
        @Volatile
        private var INSTANCE: SubStudyDatabase? = null

        fun getInstance(context: Context): SubStudyDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SubStudyDatabase::class.java,
                    "sub_study_lkg.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
