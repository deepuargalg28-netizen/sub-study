package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "child_profile")
data class ChildProfileEntity(
    @PrimaryKey val id: Int = 1,
    val childName: String = "Little Star",
    val avatarEmoji: String = "🌟",
    val streakDays: Int = 1,
    val totalStars: Int = 0,
    val todayCompletedActivities: Int = 0,
    val dailyGoalActivities: Int = 5,
    val lastStudyDateKey: String = ""
)

@Entity(tableName = "topic_progress")
data class TopicProgressEntity(
    @PrimaryKey val topicId: String,
    val subjectId: String,
    val topicTitle: String,
    val starsEarned: Int = 0,
    val questionsCorrect: Int = 0,
    val questionsAttempted: Int = 0,
    val completionsCount: Int = 0,
    val lastStudiedMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "session_logs")
data class SessionLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subjectId: String,
    val topicTitle: String,
    val starsEarned: Int,
    val correctAnswers: Int,
    val totalQuestions: Int,
    val durationSeconds: Int,
    val timestamp: Long = System.currentTimeMillis()
)
