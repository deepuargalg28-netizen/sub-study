package com.example.data.local

import com.example.data.model.LkgCurriculumRepository
import com.example.data.model.TopicUnit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SubStudyRepository(
    private val dao: SubStudyDao,
    private val settingsDataStore: ParentSettingsDataStore
) {
    val profileFlow: Flow<ChildProfileEntity> = dao.observeProfile().map {
        it ?: ChildProfileEntity()
    }

    val topicProgressFlow: Flow<List<TopicProgressEntity>> = dao.observeAllTopicProgress()

    val recentSessionsFlow: Flow<List<SessionLogEntity>> = dao.observeRecentSessions()

    val parentSettingsFlow: Flow<ParentSettings> = settingsDataStore.settingsFlow

    fun todayDateKey(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    suspend fun ensureInitialized() {
        val today = todayDateKey()
        val existing = dao.getProfileOnce()
        if (existing == null) {
            dao.upsertProfile(
                ChildProfileEntity(
                    id = 1,
                    childName = "Little Star",
                    avatarEmoji = "🌟",
                    streakDays = 1,
                    totalStars = 0,
                    todayCompletedActivities = 0,
                    dailyGoalActivities = 5,
                    lastStudyDateKey = today
                )
            )
        } else if (existing.lastStudyDateKey != today) {
            val newStreak = if (existing.lastStudyDateKey.isNotEmpty()) existing.streakDays + 1 else 1
            dao.upsertProfile(
                existing.copy(
                    streakDays = newStreak,
                    todayCompletedActivities = 0,
                    lastStudyDateKey = today
                )
            )
        }
    }

    suspend fun updateChildProfile(name: String, avatarEmoji: String, dailyGoal: Int) {
        val current = dao.getProfileOnce() ?: ChildProfileEntity(lastStudyDateKey = todayDateKey())
        dao.upsertProfile(
            current.copy(
                childName = name.ifBlank { "Little Star" },
                avatarEmoji = avatarEmoji,
                dailyGoalActivities = dailyGoal.coerceIn(3, 15)
            )
        )
    }

    suspend fun recordLessonCompletion(
        topic: TopicUnit,
        starsEarned: Int,
        correctAnswers: Int,
        totalQuestions: Int,
        durationSeconds: Int
    ) {
        val today = todayDateKey()
        val currentProfile = dao.getProfileOnce() ?: ChildProfileEntity(lastStudyDateKey = today)
        val resetTodayCount = if (currentProfile.lastStudyDateKey == today) {
            currentProfile.todayCompletedActivities + 1
        } else 1
        dao.upsertProfile(
            currentProfile.copy(
                totalStars = currentProfile.totalStars + starsEarned,
                todayCompletedActivities = resetTodayCount,
                lastStudyDateKey = today
            )
        )

        val prevTopic = dao.getTopicProgressOnce(topic.id)
        dao.upsertTopicProgress(
            TopicProgressEntity(
                topicId = topic.id,
                subjectId = topic.subjectId.name,
                topicTitle = topic.title,
                starsEarned = (prevTopic?.starsEarned ?: 0) + starsEarned,
                questionsCorrect = (prevTopic?.questionsCorrect ?: 0) + correctAnswers,
                questionsAttempted = (prevTopic?.questionsAttempted ?: 0) + totalQuestions,
                completionsCount = (prevTopic?.completionsCount ?: 0) + 1,
                lastStudiedMillis = System.currentTimeMillis()
            )
        )

        dao.insertSessionLog(
            SessionLogEntity(
                subjectId = topic.subjectId.name,
                topicTitle = topic.title,
                starsEarned = starsEarned,
                correctAnswers = correctAnswers,
                totalQuestions = totalQuestions,
                durationSeconds = durationSeconds
            )
        )
    }

    suspend fun awardBonusStars(stars: Int, reasonTitle: String, subjectId: String = "GAMES") {
        val today = todayDateKey()
        val currentProfile = dao.getProfileOnce() ?: ChildProfileEntity(lastStudyDateKey = today)
        dao.upsertProfile(
            currentProfile.copy(
                totalStars = currentProfile.totalStars + stars,
                todayCompletedActivities = currentProfile.todayCompletedActivities + 1,
                lastStudyDateKey = today
            )
        )
        dao.insertSessionLog(
            SessionLogEntity(
                subjectId = subjectId,
                topicTitle = reasonTitle,
                starsEarned = stars,
                correctAnswers = 1,
                totalQuestions = 1,
                durationSeconds = 30
            )
        )
    }

    suspend fun addElapsedSeconds(delta: Int) {
        settingsDataStore.addElapsedSeconds(delta, todayDateKey())
    }

    suspend fun resetTodayTimer() {
        settingsDataStore.resetTodayTimer(todayDateKey())
    }

    suspend fun setSessionLimitMinutes(minutes: Int) = settingsDataStore.setSessionLimitMinutes(minutes)
    suspend fun setAutoplayEnabled(enabled: Boolean) = settingsDataStore.setAutoplayEnabled(enabled)
    suspend fun setVoiceTeacherEnabled(enabled: Boolean) = settingsDataStore.setVoiceTeacherEnabled(enabled)
    suspend fun setSoundEffectsEnabled(enabled: Boolean) = settingsDataStore.setSoundEffectsEnabled(enabled)
    suspend fun setSpeechRate(rate: Float) = settingsDataStore.setSpeechRate(rate)
    suspend fun setExitProtectionEnabled(enabled: Boolean) = settingsDataStore.setExitProtectionEnabled(enabled)
    suspend fun updatePin(pin: String) = settingsDataStore.updatePin(pin)

    suspend fun resetProgress() {
        dao.clearTopicProgress()
        dao.clearSessionLogs()
        val current = dao.getProfileOnce() ?: ChildProfileEntity()
        dao.upsertProfile(current.copy(totalStars = 0, todayCompletedActivities = 0, streakDays = 1))
    }

    fun getAllTopics(): List<TopicUnit> = LkgCurriculumRepository.allTopics
}
