package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.DrawingPurple
import com.example.ui.theme.DrawingPurpleSoft
import com.example.ui.theme.EnglishPink
import com.example.ui.theme.EnglishPinkSoft
import com.example.ui.theme.EvsGreen
import com.example.ui.theme.EvsGreenSoft
import com.example.ui.theme.HindiAmber
import com.example.ui.theme.HindiAmberSoft
import com.example.ui.theme.MathsBlue
import com.example.ui.theme.MathsBlueSoft

enum class SubjectId(
    val title: String,
    val hindiLabel: String,
    val shortBadge: String,
    val primaryColor: Color,
    val softColor: Color
) {
    ENGLISH("English", "अंग्रेजी", "ABC", EnglishPink, EnglishPinkSoft),
    MATHS("Maths", "गणित", "123", MathsBlue, MathsBlueSoft),
    HINDI("Hindi", "हिन्दी", "अ", HindiAmber, HindiAmberSoft),
    EVS("EVS", "परिवेश", "🌿", EvsGreen, EvsGreenSoft),
    DRAWING("Drawing", "चित्रकला", "🎨", DrawingPurple, DrawingPurpleSoft)
}

enum class VisualKind {
    LETTER_CARD,
    NUMBER_COUNT,
    SHAPE_CARD,
    COMPARISON_CARD,
    PATTERN_CARD,
    HINDI_LETTER,
    EVS_ITEM,
    COLOR_SPLASH,
    DRAWING_GUIDE
}

data class LessonItem(
    val id: String,
    val title: String,
    val displayGlyph: String,
    val subGlyph: String,
    val englishWord: String,
    val hindiHint: String,
    val phonicsText: String,
    val teacherIntro: String,
    val teacherExplain: String,
    val visualKind: VisualKind,
    val countValue: Int = 1,
    val accentColor: Color = EnglishPink,
    val tracingGuide: String? = null
)

data class QuizOption(
    val id: String,
    val label: String,
    val subLabel: String,
    val glyph: String,
    val spokenKeywords: List<String>,
    val accentColor: Color
)

data class QuizQuestion(
    val id: String,
    val promptText: String,
    val promptVoice: String,
    val options: List<QuizOption>,
    val correctOptionId: String,
    val gentleRetryVoice: String,
    val praiseVoice: String
)

enum class DrawingMode {
    NONE,
    TRACE_GUIDE,
    COLORING_BOOK,
    FREE_DRAW
}

data class TopicUnit(
    val id: String,
    val subjectId: SubjectId,
    val title: String,
    val hindiTitle: String,
    val badgeGlyph: String,
    val teacherIntroVoice: String,
    val revisionVoice: String,
    val items: List<LessonItem>,
    val questions: List<QuizQuestion>,
    val drawingMode: DrawingMode = DrawingMode.NONE,
    val tracingTargets: List<String> = emptyList()
)

data class RhymeItem(
    val id: String,
    val title: String,
    val hindiSubtitle: String,
    val badgeGlyph: String,
    val color: Color,
    val lyrics: List<String>,
    // Frequency in Hz, duration in ms
    val melodyNotes: List<Pair<Float, Int>>
)

data class MemoryCardItem(
    val pairId: String,
    val title: String,
    val glyph: String,
    val spokenWord: String,
    val color: Color
)

data class RewardBadge(
    val id: String,
    val title: String,
    val hindiTitle: String,
    val glyph: String,
    val requiredStars: Int,
    val color: Color
)
