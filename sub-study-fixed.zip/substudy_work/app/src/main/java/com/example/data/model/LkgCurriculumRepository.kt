package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BerryPink
import com.example.ui.theme.BrandBlueLight
import com.example.ui.theme.DrawingPurple
import com.example.ui.theme.EnglishPink
import com.example.ui.theme.EvsGreen
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.GentleAmber
import com.example.ui.theme.GrapePurple
import com.example.ui.theme.HindiAmber
import com.example.ui.theme.MathsBlue
import com.example.ui.theme.WarmOrange

object LkgCurriculumRepository {

    val allTopics: List<TopicUnit> = listOf(
        // ==================== ENGLISH ====================
        TopicUnit(
            id = "eng_af",
            subjectId = SubjectId.ENGLISH,
            title = "Letters A to F & Phonics",
            hindiTitle = "A से F और उनकी आवाज़",
            badgeGlyph = "🍎",
            teacherIntroVoice = "Namaste Little Star! Aaj hum English mein A se F tak letters aur unki phonics aawaz seekhenge! Dhyan se suno!",
            revisionVoice = "Waah! Humne seekha A for Apple, B for Ball, C for Cat, D for Dog, E for Elephant aur F for Fish!",
            items = listOf(
                LessonItem(
                    id = "a_apple",
                    title = "A for Apple",
                    displayGlyph = "A",
                    subGlyph = "🍎",
                    englishWord = "Apple",
                    hindiHint = "सेब (Seb)",
                    phonicsText = "ए... ए... Apple!",
                    teacherIntro = "Yeh hai bada letter A! A says Ay... Ay... Apple!",
                    teacherExplain = "Laal laal meetha Apple shuru hota hai letter A se!",
                    visualKind = VisualKind.LETTER_CARD,
                    accentColor = EnglishPink,
                    tracingGuide = "A"
                ),
                LessonItem(
                    id = "b_ball",
                    title = "B for Ball",
                    displayGlyph = "B",
                    subGlyph = "⚽",
                    englishWord = "Ball",
                    hindiHint = "गेंद (Gend)",
                    phonicsText = "ब... ब... Ball!",
                    teacherIntro = "Ab dekho letter B! B says Buh... Buh... Ball!",
                    teacherExplain = "Gol gol uchhalti hui Ball shuru hoti hai B se!",
                    visualKind = VisualKind.LETTER_CARD,
                    accentColor = MathsBlue,
                    tracingGuide = "B"
                ),
                LessonItem(
                    id = "c_cat",
                    title = "C for Cat",
                    displayGlyph = "C",
                    subGlyph = "🐱",
                    englishWord = "Cat",
                    hindiHint = "बिल्ली (Billi)",
                    phonicsText = "क... क... Cat!",
                    teacherIntro = "Yeh hai cute letter C! C says Kuh... Kuh... Cat!",
                    teacherExplain = "Meow meow karne wali Cat shuru hoti hai C se!",
                    visualKind = VisualKind.LETTER_CARD,
                    accentColor = HindiAmber,
                    tracingGuide = "C"
                ),
                LessonItem(
                    id = "d_dog",
                    title = "D for Dog",
                    displayGlyph = "D",
                    subGlyph = "🐶",
                    englishWord = "Dog",
                    hindiHint = "कुत्ता (Kutta)",
                    phonicsText = "ड... ड... Dog!",
                    teacherIntro = "Ab aaya letter D! D says Duh... Duh... Dog!",
                    teacherExplain = "Pyara puppy Dog shuru hota hai letter D se!",
                    visualKind = VisualKind.LETTER_CARD,
                    accentColor = WarmOrange,
                    tracingGuide = "D"
                ),
                LessonItem(
                    id = "e_elephant",
                    title = "E for Elephant",
                    displayGlyph = "E",
                    subGlyph = "🐘",
                    englishWord = "Elephant",
                    hindiHint = "हाथी (Haathi)",
                    phonicsText = "ए... ए... Elephant!",
                    teacherIntro = "Dekho bada sa E! E says Eh... Eh... Elephant!",
                    teacherExplain = "Lambi soond wala bada Haathi yaani Elephant!",
                    visualKind = VisualKind.LETTER_CARD,
                    accentColor = GrapePurple
                ),
                LessonItem(
                    id = "f_fish",
                    title = "F for Fish",
                    displayGlyph = "F",
                    subGlyph = "🐟",
                    englishWord = "Fish",
                    hindiHint = "मछली (Machli)",
                    phonicsText = "फ... फ... Fish!",
                    teacherIntro = "Aur yeh hai letter F! F says Fuh... Fuh... Fish!",
                    teacherExplain = "Paani mein tairti machli yaani Fish shuru hoti hai F se!",
                    visualKind = VisualKind.LETTER_CARD,
                    accentColor = BrandBlueLight
                )
            ),
            questions = listOf(
                QuizQuestion(
                    id = "q_eng_1",
                    promptText = "Which picture starts with A?",
                    promptVoice = "Chalo batao! Inmein se A for Apple kaunsa hai? Tap karo ya bolo Apple!",
                    options = listOf(
                        QuizOption("opt_apple", "A - Apple", "सेब", "🍎", listOf("apple", "a", "seb", "ay"), EnglishPink),
                        QuizOption("opt_ball", "B - Ball", "गेंद", "⚽", listOf("ball", "b", "gend"), MathsBlue),
                        QuizOption("opt_cat", "C - Cat", "बिल्ली", "🐱", listOf("cat", "c", "billi"), HindiAmber)
                    ),
                    correctOptionId = "opt_apple",
                    gentleRetryVoice = "Koi baat nahi beta! Apple laal rang ka fruit hota hai aur A se shuru hota hai. Phir se try karo!",
                    praiseVoice = "Shabaash Little Star! A for Apple bilkul sahi jawab hai!"
                ),
                QuizQuestion(
                    id = "q_eng_2",
                    promptText = "Tap the picture for C!",
                    promptVoice = "Ab batao, C for kya hota hai? Jo Meow Meow karti hai!",
                    options = listOf(
                        QuizOption("opt_dog", "D - Dog", "कुत्ता", "🐶", listOf("dog", "d"), WarmOrange),
                        QuizOption("opt_cat", "C - Cat", "बिल्ली", "🐱", listOf("cat", "c", "billi", "meow"), HindiAmber),
                        QuizOption("opt_fish", "F - Fish", "मछली", "🐟", listOf("fish", "f"), MathsBlue)
                    ),
                    correctOptionId = "opt_cat",
                    gentleRetryVoice = "Almost there! Meow meow Cat shuru hoti hai C se! Cat par tap karo!",
                    praiseVoice = "Bahut badhiya! C for Cat! You earned a bright star!"
                )
            )
        ),
        TopicUnit(
            id = "eng_gm",
            subjectId = SubjectId.ENGLISH,
            title = "Letters G to M & Words",
            hindiTitle = "G से M तक नए शब्द",
            badgeGlyph = "🦁",
            teacherIntroVoice = "Aaj hum G se M tak naye English letters aur pyare words seekhenge!",
            revisionVoice = "Super! G Grapes, H Hat, I Ice Cream, J Jug, K Kite, L Lion aur M Mango!",
            items = listOf(
                LessonItem("g_grapes", "G for Grapes", "G", "🍇", "Grapes", "अंगूर", "ग... ग... Grapes!", "Yeh hai letter G! G for yummy Grapes!", "Meethe hare angoor shuru hote hain G se!", VisualKind.LETTER_CARD, accentColor = GrapePurple),
                LessonItem("h_hat", "H for Hat", "H", "👒", "Hat", "टोपी", "ह... ह... Hat!", "Dekho letter H! H for Hat!", "Dhoop mein pehanne wali Hat shuru hoti hai H se!", VisualKind.LETTER_CARD, accentColor = WarmOrange),
                LessonItem("i_icecream", "I for Ice Cream", "I", "🍦", "Ice Cream", "आइसक्रीम", "आ... आ... Ice Cream!", "Yummy letter I! I for thandi thandi Ice Cream!", "Sabko pasand aane wali Ice Cream shuru hoti hai I se!", VisualKind.LETTER_CARD, accentColor = EnglishPink),
                LessonItem("k_kite", "K for Kite", "K", "🪁", "Kite", "पतंग", "क... क... Kite!", "Aasmaan mein udti K for Kite!", "Rangeen patang yaani Kite shuru hoti hai K se!", VisualKind.LETTER_CARD, accentColor = MathsBlue),
                LessonItem("l_lion", "L for Lion", "L", "🦁", "Lion", "शेर", "ल... ल... Lion!", "Jungle ka raja L for Lion!", "Roar karne wala Sher yaani Lion shuru hota hai L se!", VisualKind.LETTER_CARD, accentColor = HindiAmber),
                LessonItem("m_mango", "M for Mango", "M", "🥭", "Mango", "आम", "म... म... Mango!", "Phalon ka raja M for Mango!", "Peela meetha Aam yaani Mango shuru hota hai M se!", VisualKind.LETTER_CARD, accentColor = EvsGreen)
            ),
            questions = listOf(
                QuizQuestion(
                    id = "q_eng_gm_1",
                    promptText = "Find K for Kite!",
                    promptVoice = "Aasmaan mein kya udta hai? K for Kite par tap karo!",
                    options = listOf(
                        QuizOption("opt_kite", "K - Kite", "पतंग", "🪁", listOf("kite", "k", "patang"), MathsBlue),
                        QuizOption("opt_grapes", "G - Grapes", "अंगूर", "🍇", listOf("grapes", "g"), GrapePurple),
                        QuizOption("opt_mango", "M - Mango", "आम", "🥭", listOf("mango", "m"), HindiAmber)
                    ),
                    correctOptionId = "opt_kite",
                    gentleRetryVoice = "Pyaare bachche, Kite yaani patang par tap karo! Woh K se shuru hoti hai!",
                    praiseVoice = "Wah! K for Kite bilkul sahi hai!"
                ),
                QuizQuestion(
                    id = "q_eng_gm_2",
                    promptText = "Which one is L for Lion?",
                    promptVoice = "Jungle ka raja kaun hai? L for Lion ko choose karo!",
                    options = listOf(
                        QuizOption("opt_ice", "I - Ice Cream", "आइसक्रीम", "🍦", listOf("ice cream", "i"), EnglishPink),
                        QuizOption("opt_lion", "L - Lion", "शेर", "🦁", listOf("lion", "l", "sher"), HindiAmber),
                        QuizOption("opt_hat", "H - Hat", "टोपी", "👒", listOf("hat", "h"), WarmOrange)
                    ),
                    correctOptionId = "opt_lion",
                    gentleRetryVoice = "Koi baat nahi! Lion yaani sher ki photo par tap karo!",
                    praiseVoice = "Roar! Shabaash! L for Lion bilkul correct hai!"
                )
            )
        ),
        TopicUnit(
            id = "eng_nz",
            subjectId = SubjectId.ENGLISH,
            title = "Letters N to Z & Tracing",
            hindiTitle = "N से Z और अक्षर लिखना",
            badgeGlyph = "🦓",
            teacherIntroVoice = "Chalo ab N se Z tak baaki sabhi letters seekhein aur finger se trace karein!",
            revisionVoice = "Awesome! A to Z sabhi letters ab aapko aate hain!",
            items = listOf(
                LessonItem("n_nest", "N for Nest", "N", "🪺", "Nest", "घोंसला", "न... न... Nest!", "N for Nest — chidiya ka pyara ghar!", "Birds apna ghar Nest banati hain!", VisualKind.LETTER_CARD, accentColor = EvsGreen),
                LessonItem("o_orange", "O for Orange", "O", "🍊", "Orange", "संतरा", "ओ... ओ... Orange!", "Gol gol O for Orange!", "Khatta meetha santra shuru hota hai O se!", VisualKind.LETTER_CARD, accentColor = WarmOrange, tracingGuide = "O"),
                LessonItem("r_rabbit", "R for Rabbit", "R", "🐰", "Rabbit", "खरगोश", "र... र... Rabbit!", "Uchhalta koodta R for Rabbit!", "Safed pyara khargosh R se shuru hota hai!", VisualKind.LETTER_CARD, accentColor = EnglishPink),
                LessonItem("s_sun", "S for Sun", "S", "☀️", "Sun", "सूरज", "स... स... Sun!", "Chamakta hua S for Sun!", "Subah roshni dene wala Sooraj yaani Sun!", VisualKind.LETTER_CARD, accentColor = HindiAmber, tracingGuide = "S"),
                LessonItem("u_umbrella", "U for Umbrella", "U", "☂️", "Umbrella", "छाता", "अ... अ... Umbrella!", "Baarish se bachaye U for Umbrella!", "Barish mein hum Umbrella kholte hain!", VisualKind.LETTER_CARD, accentColor = MathsBlue),
                LessonItem("z_zebra", "Z for Zebra", "Z", "🦓", "Zebra", "ज़ेब्रा", "ज़... ज़... Zebra!", "Black and white stripes wala Z for Zebra!", "Z alphabet ka aakhiri aur cute letter hai!", VisualKind.LETTER_CARD, accentColor = GrapePurple)
            ),
            questions = listOf(
                QuizQuestion(
                    id = "q_eng_nz_1",
                    promptText = "Tap S for Sun!",
                    promptVoice = "Din mein aasmaan mein kaun chamakta hai? S for Sun par tap karo!",
                    options = listOf(
                        QuizOption("opt_sun", "S - Sun", "सूरज", "☀️", listOf("sun", "s", "sooraj"), HindiAmber),
                        QuizOption("opt_umb", "U - Umbrella", "छाता", "☂️", listOf("umbrella", "u"), MathsBlue),
                        QuizOption("opt_zebra", "Z - Zebra", "ज़ेब्रा", "🦓", listOf("zebra", "z"), GrapePurple)
                    ),
                    correctOptionId = "opt_sun",
                    gentleRetryVoice = "Chalo phir se dekhte hain! Peela chamakta Sooraj hi Sun hai!",
                    praiseVoice = "You shine like the Sun! S for Sun bilkul sahi!"
                )
            ),
            drawingMode = DrawingMode.TRACE_GUIDE,
            tracingTargets = listOf("A", "O", "S")
        ),

        // ==================== MATHS ====================
        TopicUnit(
            id = "math_1_10",
            subjectId = SubjectId.MATHS,
            title = "Counting 1 to 10",
            hindiTitle = "1 से 10 तक गिनती",
            badgeGlyph = "🔢",
            teacherIntroVoice = "Namaste! Aaj Maths mein hum 1 se 10 tak counting karenge! Mere saath gino!",
            revisionVoice = "Bahut achhe! 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 — aapne ginti seekh li!",
            items = listOf(
                LessonItem("num_1", "Number 1", "1", "🍎", "One (1)", "एक (Ek)", "1 — One Apple", "Yeh hai Number 1! Dekho ek pyara Apple!", "Sirf 1 cheez ko hum kehte hain One!", VisualKind.NUMBER_COUNT, countValue = 1, accentColor = EnglishPink, tracingGuide = "1"),
                LessonItem("num_2", "Number 2", "2", "⭐", "Two (2)", "दो (Do)", "1, 2 — Two Stars", "Ab gino Number 2! One, Two — Do Stars!", "Jab do cheezein hon toh woh Two hota hai!", VisualKind.NUMBER_COUNT, countValue = 2, accentColor = HindiAmber, tracingGuide = "2"),
                LessonItem("num_3", "Number 3", "3", "🎈", "Three (3)", "तीन (Teen)", "1, 2, 3 — Three Balloons", "Yeh hai Number 3! One, Two, Three Balloons!", "Teen rang birange gubbare yaani Three!", VisualKind.NUMBER_COUNT, countValue = 3, accentColor = MathsBlue, tracingGuide = "3"),
                LessonItem("num_5", "Number 5", "5", "🌸", "Five (5)", "पाँच (Paanch)", "1, 2, 3, 4, 5 — Five Flowers", "Dekho Number 5! Ek haath mein 5 fingers hoti hain!", "Chalo gino: 1, 2, 3, 4, 5 sundar phool!", VisualKind.NUMBER_COUNT, countValue = 5, accentColor = EvsGreen),
                LessonItem("num_10", "Number 10", "10", "🦋", "Ten (10)", "दस (Das)", "1 to 10 — Ten Butterflies", "Aur yeh hai Number 10! Dono haathon ki 10 fingers!", "One, two, three, four, five, six, seven, eight, nine, ten!", VisualKind.NUMBER_COUNT, countValue = 10, accentColor = GrapePurple)
            ),
            questions = listOf(
                QuizQuestion(
                    id = "q_math_count_1",
                    promptText = "How many stars? ⭐⭐⭐",
                    promptVoice = "Gino aur batao! Yahan kitne stars hain? One, Two, Three!",
                    options = listOf(
                        QuizOption("opt_2", "2", "दो", "⭐⭐", listOf("2", "two", "do"), MathsBlue),
                        QuizOption("opt_3", "3", "तीन", "⭐⭐⭐", listOf("3", "three", "teen"), HindiAmber),
                        QuizOption("opt_5", "5", "पाँच", "⭐⭐⭐⭐⭐", listOf("5", "five", "paanch"), EvsGreen)
                    ),
                    correctOptionId = "opt_3",
                    gentleRetryVoice = "Aaram se ungli rakh kar gino: Ek, Do, Teen! Ab 3 par tap karo!",
                    praiseVoice = "Shabaash! 1, 2, 3 — Three stars bilkul sahi!"
                ),
                QuizQuestion(
                    id = "q_math_count_2",
                    promptText = "Find Number 5!",
                    promptVoice = "Hamare ek haath mein kitni ungliyan hoti hain? Number 5 ko tap karo!",
                    options = listOf(
                        QuizOption("opt_1", "1", "एक", "1️⃣", listOf("1", "one", "ek"), EnglishPink),
                        QuizOption("opt_5", "5", "पाँच", "5️⃣", listOf("5", "five", "paanch"), EvsGreen),
                        QuizOption("opt_9", "9", "नौ", "9️⃣", listOf("9", "nine", "nau"), GrapePurple)
                    ),
                    correctOptionId = "opt_5",
                    gentleRetryVoice = "Chalo phir se ginte hain: 1, 2, 3, 4, 5! Five wala card tap karo!",
                    praiseVoice = "High Five! Number 5 bilkul sahi hai!"
                )
            )
        ),
        TopicUnit(
            id = "math_11_100",
            subjectId = SubjectId.MATHS,
            title = "Numbers 11 to 100",
            hindiTitle = "11 से 100 की पहचान",
            badgeGlyph = "💯",
            teacherIntroVoice = "Ab hum bade numbers 11 se 100 tak pehchanna seekhenge! Taiyaar ho?",
            revisionVoice = "Amazing! 10, 20, 30, 40, 50 se lekar 100 tak numbers aap pehchan gaye!",
            items = listOf(
                LessonItem("num_15", "11 to 20", "20", "🔢", "Twenty (20)", "बीस (Bees)", "11, 12, 13... 20!", "1 aur 0 milkar 10, aur 2 aur 0 milkar banta hai 20!", "11 se 20 tak ginti roz bolne se pakki ho jaati hai!", VisualKind.NUMBER_COUNT, countValue = 4, accentColor = MathsBlue),
                LessonItem("num_50", "Half Century 50", "50", "🎯", "Fifty (50)", "पचास (Pachaas)", "25, 30, 40, 50!", "5 aur 0 milkar banta hai Number 50!", "50 aadhi century hoti hai — bahut badhiya!", VisualKind.NUMBER_COUNT, countValue = 5, accentColor = AmberGold),
                LessonItem("num_100", "Century 100!", "100", "🏆", "Hundred (100)", "सौ (Sau)", "60, 70, 80, 90, 100!", "1 ke peeche do 0 lagane se banta hai bada sa 100!", "100 matlab full marks aur full celebration!", VisualKind.NUMBER_COUNT, countValue = 6, accentColor = EvsGreen)
            ),
            questions = listOf(
                QuizQuestion(
                    id = "q_math_100",
                    promptText = "Tap Number 100!",
                    promptVoice = "Inmein se Hundred yaani 100 kaunsa hai? Tap karo!",
                    options = listOf(
                        QuizOption("opt_20", "20", "बीस", "2️⃣0️⃣", listOf("20", "twenty"), MathsBlue),
                        QuizOption("opt_50", "50", "पचास", "5️⃣0️⃣", listOf("50", "fifty"), HindiAmber),
                        QuizOption("opt_100", "100", "सौ", "💯", listOf("100", "hundred", "sau"), EvsGreen)
                    ),
                    correctOptionId = "opt_100",
                    gentleRetryVoice = "Dekho, 1 aur do 0 — 100 par tap karo beta!",
                    praiseVoice = "100 out of 100! Bahut hi badhiya Little Star!"
                )
            )
        ),
        TopicUnit(
            id = "math_shapes_patterns",
            subjectId = SubjectId.MATHS,
            title = "Shapes, Patterns & Big/Small",
            hindiTitle = "आकार, पैटर्न और छोटा-बड़ा",
            badgeGlyph = "⭐",
            teacherIntroVoice = "Aaj hum gol Circle, teekha Triangle, Square, aur Big vs Small seekhenge!",
            revisionVoice = "Waah! Circle, Square, Triangle, Star aur Big-Small sab clear ho gaya!",
            items = listOf(
                LessonItem("shape_circle", "Circle (गोल)", "⭕", "☀️", "Circle", "गोल आकार", "Round and Round Circle!", "Yeh hai Circle — bilkul gol jaise Suraj ya Roti!", "Circle ka koi corner nahi hota!", VisualKind.SHAPE_CARD, accentColor = EnglishPink, tracingGuide = "O"),
                LessonItem("shape_square", "Square (चौकोर)", "🟦", "🎁", "Square", "चौकोर (4 बराबर साइड)", "4 Equal Sides!", "Yeh hai Square — iske 4 corners aur 4 barabar sides hain!", "Gift box aur Ludo dice Square jaise dikhte hain!", VisualKind.SHAPE_CARD, accentColor = MathsBlue),
                LessonItem("shape_triangle", "Triangle (त्रिकोण)", "🔺", "🍕", "Triangle", "तीन कोने", "3 Sides, 3 Corners!", "Yeh hai Triangle — samosa aur pizza slice jaisa!", "Triangle mein 1, 2, 3 sides hoti hain!", VisualKind.SHAPE_CARD, accentColor = HindiAmber),
                LessonItem("comp_big_small", "Big vs Small", "🐘🐭", "⚖️", "Big & Small", "बड़ा और छोटा", "Elephant Big, Mouse Small!", "Dekho Haathi kitna Big hai, aur Chuha kitna Small!", "Badi cheez ko Big aur chhoti cheez ko Small kehte hain!", VisualKind.COMPARISON_CARD, accentColor = EvsGreen),
                LessonItem("pattern_ab", "Colour Pattern", "🔴🔵🔴🔵", "✨", "AB Pattern", "रंगों का पैटर्न", "Red, Blue, Red, Blue!", "Pattern mein cheezein baar baar same order mein aati hain!", "Red ke baad Blue, phir Red, toh agla kya hoga? Blue!", VisualKind.PATTERN_CARD, accentColor = GrapePurple)
            ),
            questions = listOf(
                QuizQuestion(
                    id = "q_shape_1",
                    promptText = "Which shape is round like a Ball?",
                    promptVoice = "Kaunsa shape bilkul gol hota hai? Circle par tap karo!",
                    options = listOf(
                        QuizOption("opt_circle", "Circle", "गोल", "⭕", listOf("circle", "round", "gol"), EnglishPink),
                        QuizOption("opt_square", "Square", "चौकोर", "🟦", listOf("square", "box"), MathsBlue),
                        QuizOption("opt_tri", "Triangle", "त्रिकोण", "🔺", listOf("triangle"), HindiAmber)
                    ),
                    correctOptionId = "opt_circle",
                    gentleRetryVoice = "Koi baat nahi! Gol shape ko Circle kehte hain, gol wale card par tap karo!",
                    praiseVoice = "Shabaash! Circle bilkul gol aur sahi jawab hai!"
                ),
                QuizQuestion(
                    id = "q_pattern_1",
                    promptText = "Complete Pattern: ⭐ ❤️ ⭐ ___?",
                    promptVoice = "Pattern poora karo! Star, Heart, Star... ab aage kya aayega?",
                    options = listOf(
                        QuizOption("opt_heart", "Heart", "दिल", "❤️", listOf("heart", "dil", "red"), EnglishPink),
                        QuizOption("opt_star", "Star", "तारा", "⭐", listOf("star", "tara"), HindiAmber)
                    ),
                    correctOptionId = "opt_heart",
                    gentleRetryVoice = "Dhyan se dekho: Star ke baad Heart aata hai! Heart tap karo!",
                    praiseVoice = "Genius! Star, Heart, Star, Heart! Pattern complete!"
                )
            )
        ),

        // ==================== HINDI ====================
        TopicUnit(
            id = "hindi_swar",
            subjectId = SubjectId.HINDI,
            title = "स्वर परिचय (अ – अः)",
            hindiTitle = "अ से अनार, आ से आम",
            badgeGlyph = "🥭",
            teacherIntroVoice = "Namaste pyare bachchon! Aaj hum Hindi ke Swar seekhenge — अ से अनार aur आ से आम!",
            revisionVoice = "Bahut sundar! अ से अनार, आ से आम, इ से इमली, ई से ईख, उ से उल्लू — sab yaad ho gaya!",
            items = listOf(
                LessonItem("swar_a", "अ से अनार", "अ", "🍎", "Anar (Pomegranate)", "दानेदार लाल अनार", "अ... अ... अनार!", "Yeh hai स्वर अ! अ से होता है लाल मीठा अनार!", "अनार khane se hum strong bante hain!", VisualKind.HINDI_LETTER, accentColor = EnglishPink),
                LessonItem("swar_aa", "आ से आम", "आ", "🥭", "Aam (Mango)", "फलों का राजा आम", "आ... आ... आम!", "Yeh hai आ! आ से रसीला मीठा आम!", "Garmiyon mein sabko pasand aata hai Aam!", VisualKind.HINDI_LETTER, accentColor = HindiAmber),
                LessonItem("swar_i", "इ से इमली", "इ", "🌿", "Imli (Tamarind)", "खट्टी मीठी इमली", "इ... इ... इमली!", "Yeh hai इ! इ से खट्टी-मीठी इमली!", "इमली का स्वाद बड़ा मजेदार होता है!", VisualKind.HINDI_LETTER, accentColor = EvsGreen),
                LessonItem("swar_u", "उ से उल्लू", "उ", "🦉", "Ullu (Owl)", "रात का दोस्त उल्लू", "उ... उ... उल्लू!", "Yeh hai उ! उ से गोल आंखों वाला उल्लू!", "उल्लू raat ko jaagta hai aur hoot hoot karta hai!", VisualKind.HINDI_LETTER, accentColor = GrapePurple),
                LessonItem("swar_o", "ओ से ओखली", "ओ", "🥣", "Okhli", "मसाले कूटने की ओखली", "ओ... ओ... ओखली!", "Aur yeh hai ओ! ओ से ओखली!", "Dadi maa okhli mein masale koot-ti hain!", VisualKind.HINDI_LETTER, accentColor = MathsBlue)
            ),
            questions = listOf(
                QuizQuestion(
                    id = "q_hindi_swar_1",
                    promptText = "आ से क्या होता है?",
                    promptVoice = "Batao bachcho, आ से फलों का राजा क्या होता है? Tap karo!",
                    options = listOf(
                        QuizOption("opt_aam", "आ - आम", "Mango", "🥭", listOf("aam", "mango", "aa"), HindiAmber),
                        QuizOption("opt_ullu", "उ - उल्लू", "Owl", "🦉", listOf("ullu", "owl"), GrapePurple),
                        QuizOption("opt_imli", "इ - इमली", "Tamarind", "🌿", listOf("imli"), EvsGreen)
                    ),
                    correctOptionId = "opt_aam",
                    gentleRetryVoice = "Koi baat nahi! Peela meetha Aam hi आ se hota hai. Aam par tap karo!",
                    praiseVoice = "Bahut khoob! आ से आम bilkul sahi jawab hai!"
                )
            )
        ),
        TopicUnit(
            id = "hindi_vyanjan",
            subjectId = SubjectId.HINDI,
            title = "व्यंजन व सरल शब्द (क – झ)",
            hindiTitle = "क से कबूतर, ख से खरगोश",
            badgeGlyph = "🐇",
            teacherIntroVoice = "Aaj hum Hindi ke Vyanjan aur do akshar ke saral shabd padhenge!",
            revisionVoice = "Waah! क से कबूतर, ख से खरगोश, ग से गमला, घर aur फल sab seekh liya!",
            items = listOf(
                LessonItem("vy_ka", "क से कबूतर", "क", "🕊️", "Kabutar (Pigeon)", "उड़ता कबूतर", "क... क... कबूतर!", "Yeh hai व्यंजन क! क से प्यारा कबूतर!", "कबूतर aasmaan mein udta hai!", VisualKind.HINDI_LETTER, accentColor = MathsBlue),
                LessonItem("vy_kha", "ख से खरगोश", "ख", "🐰", "Khargosh (Rabbit)", "गाजर खाता खरगोश", "ख... ख... खरगोश!", "Yeh hai ख! ख से तेज़ दौड़ने वाला खरगोश!", "खरगोश ko gaajar bahut pasand hai!", VisualKind.HINDI_LETTER, accentColor = EnglishPink),
                LessonItem("vy_ga", "ग से गमला", "ग", "🪴", "Gamla (Flower Pot)", "फूलों वाला गमला", "ग... ग... गमला!", "Yeh hai ग! ग से हरा भरा गमला!", "गमले mein hum sundar phool lagate hain!", VisualKind.HINDI_LETTER, accentColor = EvsGreen),
                LessonItem("shabd_ghar", "सरल शब्द: घर", "घर", "🏠", "Ghar (Home)", "घ + र = घर", "घ र — घर!", "Jab घ aur र milte hain, banta hai प्यारा घर!", "Hum sab apne ghar mein khush rehte hain!", VisualKind.HINDI_LETTER, accentColor = WarmOrange),
                LessonItem("shabd_phal", "सरल शब्द: फल", "फल", "🍓", "Phal (Fruits)", "फ + ल = फल", "फ ल — फल!", "फ aur ल milkar banta hai ताज़ा फल!", "Roz phal khane se sehat acchi rehti hai!", VisualKind.HINDI_LETTER, accentColor = HindiAmber)
            ),
            questions = listOf(
                QuizQuestion(
                    id = "q_hindi_vy_1",
                    promptText = "ख से क्या होता है?",
                    promptVoice = "Gajar kaun khata hai? ख से खरगोश par tap karo!",
                    options = listOf(
                        QuizOption("opt_khargosh", "ख - खरगोश", "Rabbit", "🐰", listOf("khargosh", "rabbit"), EnglishPink),
                        QuizOption("opt_gamla", "ग - गमला", "Pot", "🪴", listOf("gamla", "pot"), EvsGreen),
                        QuizOption("opt_kabutar", "क - कबूतर", "Pigeon", "🕊️", listOf("kabutar", "pigeon"), MathsBlue)
                    ),
                    correctOptionId = "opt_khargosh",
                    gentleRetryVoice = "Pyaare bachche, safed pyare Khargosh par tap karo!",
                    praiseVoice = "Shabaash! ख से खरगोश bilkul sahi!"
                ),
                QuizQuestion(
                    id = "q_hindi_shabd_2",
                    promptText = "घ + र = क्या बनता है?",
                    promptVoice = "Jahan hum rehte hain — घ aur र milkar kya banta hai?",
                    options = listOf(
                        QuizOption("opt_ghar", "घर (Home)", "घ + र", "🏠", listOf("ghar", "home"), WarmOrange),
                        QuizOption("opt_phal", "फल (Fruit)", "फ + ल", "🍓", listOf("phal", "fruit"), HindiAmber)
                    ),
                    correctOptionId = "opt_ghar",
                    gentleRetryVoice = "Chalo milakar padho: घ-र... घर! Ghar wali photo tap karo!",
                    praiseVoice = "Bahut badhiya! घ + र = घर!"
                )
            )
        ),

        // ==================== EVS ====================
        TopicUnit(
            id = "evs_animals_fruits",
            subjectId = SubjectId.EVS,
            title = "Animals, Fruits & Vegetables",
            hindiTitle = "जानवर, फल और सब्ज़ियाँ",
            badgeGlyph = "🐾",
            teacherIntroVoice = "Aaj EVS mein hum pyaare Animals, meethe Fruits aur healthy Vegetables se milenge!",
            revisionVoice = "Super! Animals hamare dost hain, aur Fruits-Vegetables humein healthy rakhte hain!",
            items = listOf(
                LessonItem("evs_cow", "Cow (गाय)", "🐄", "🥛", "Cow", "गाय हमें दूध देती है", "Moo... Moo... Cow!", "Yeh hai Cow yaani Gaay!", "Gaay humein healthy doodh deti hai!", VisualKind.EVS_ITEM, accentColor = EvsGreen),
                LessonItem("evs_peacock", "Peacock (मोर)", "🦚", "🌈", "Peacock", "भारत का राष्ट्रीय पक्षी", "Beautiful Peacock!", "Dekho sundar Peacock yaani Mor!", "Baarish mein Mor pankh phaila kar naachta hai!", VisualKind.EVS_ITEM, accentColor = MathsBlue),
                LessonItem("evs_banana", "Banana (केला)", "🍌", "💛", "Banana", "मीठा पीला केला", "Yummy Banana!", "Yeh hai peela meetha Banana!", "Banana khane se humein turant energy milti hai!", VisualKind.EVS_ITEM, accentColor = HindiAmber),
                LessonItem("evs_carrot", "Carrot (गाजर)", "🥕", "👀", "Carrot", "लाल गाजर आँखों के लिए अच्छी", "Crunchy Carrot!", "Yeh hai lal lal Carrot yaani Gaajar!", "Gaajar khane se hamari aankhein tez hoti hain!", VisualKind.EVS_ITEM, accentColor = WarmOrange)
            ),
            questions = listOf(
                QuizQuestion(
                    id = "q_evs_1",
                    promptText = "Who gives us milk?",
                    promptVoice = "Humein peene ke liye meetha doodh kaun deta hai? Tap karo!",
                    options = listOf(
                        QuizOption("opt_cow", "Cow (गाय)", "Milk", "🐄", listOf("cow", "gaay", "milk"), EvsGreen),
                        QuizOption("opt_lion", "Lion (शेर)", "Jungle", "🦁", listOf("lion", "sher"), HindiAmber),
                        QuizOption("opt_peacock", "Peacock (मोर)", "Bird", "🦚", listOf("peacock", "mor"), MathsBlue)
                    ),
                    correctOptionId = "opt_cow",
                    gentleRetryVoice = "Moo moo kaun bolti hai? Cow yaani Gaay par tap karo!",
                    praiseVoice = "Shabaash! Cow humein doodh deti hai!"
                )
            )
        ),
        TopicUnit(
            id = "evs_body_nature_colors",
            subjectId = SubjectId.EVS,
            title = "Body Parts, Family & Colours",
            hindiTitle = "शरीर के अंग, परिवार और रंग",
            badgeGlyph = "🌈",
            teacherIntroVoice = "Chalo apne Body Parts, pyari Family, Nature aur Rainbow Colours ke baare mein jaanein!",
            revisionVoice = "Wonderful! Eyes, Ears, Hands, Family aur Red-Blue-Yellow-Green colours aap jaan gaye!",
            items = listOf(
                LessonItem("evs_eyes", "Eyes (आँखें)", "👀", "🌟", "Eyes", "हम आँखों से देखते हैं", "Two Little Eyes!", "Yeh hain hamari do Eyes!", "Hum apni Eyes se yeh sundar duniya dekhte hain!", VisualKind.EVS_ITEM, accentColor = MathsBlue),
                LessonItem("evs_hands", "Hands (हाथ)", "🙌", "👏", "Hands", "हाथों से ताली और काम", "Clap Your Hands!", "Yeh hain hamare Hands!", "Hum haathon se likhte, khate aur taali bajate hain!", VisualKind.EVS_ITEM, accentColor = WarmOrange),
                LessonItem("evs_family", "My Family (मेरा परिवार)", "👨‍👩‍👧‍👦", "❤️", "Family", "मम्मी, पापा और हम", "Happy Family!", "Yeh hai hamari pyari Family!", "Mummy, Papa, Dada-Dadi sab milkar humein pyar karte hain!", VisualKind.EVS_ITEM, accentColor = EnglishPink),
                LessonItem("evs_red", "Red Colour (लाल)", "🔴", "🍓", "Red", "लाल रंग", "Bright Red!", "Yeh hai Red Colour — laal rang!", "Apple, Strawberry aur Tamatar Red hote hain!", VisualKind.COLOR_SPLASH, accentColor = Color(0xFFEF4444)),
                LessonItem("evs_green", "Green Colour (हरा)", "🟢", "🌳", "Green", "हरा रंग", "Fresh Green!", "Yeh hai Green Colour — hara rang!", "Pedon ke patte aur ghaas Green hoti hai!", VisualKind.COLOR_SPLASH, accentColor = EvsGreen)
            ),
            questions = listOf(
                QuizQuestion(
                    id = "q_evs_body_1",
                    promptText = "Which body part helps us see?",
                    promptVoice = "Hum sundar phool aur cartoons kis se dekhte hain? Eyes par tap karo!",
                    options = listOf(
                        QuizOption("opt_eyes", "Eyes (आँखें)", "See", "👀", listOf("eyes", "eye", "aankh"), MathsBlue),
                        QuizOption("opt_ears", "Ears (कान)", "Hear", "👂", listOf("ears", "ear", "kaan"), HindiAmber),
                        QuizOption("opt_hands", "Hands (हाथ)", "Clap", "🙌", listOf("hands", "hand", "haath"), WarmOrange)
                    ),
                    correctOptionId = "opt_eyes",
                    gentleRetryVoice = "Chalo apni aankhon par haath rakho — Eyes wali photo tap karo!",
                    praiseVoice = "Wah! Eyes se hum dekhte hain! Bilkul sahi!"
                ),
                QuizQuestion(
                    id = "q_evs_color_2",
                    promptText = "Tap the Green Leaf colour!",
                    promptVoice = "Pedon ke patte kis colour ke hote hain? Green par tap karo!",
                    options = listOf(
                        QuizOption("opt_red", "Red (लाल)", "Apple", "🔴", listOf("red", "laal"), Color(0xFFEF4444)),
                        QuizOption("opt_green", "Green (हरा)", "Tree", "🟢", listOf("green", "hara"), EvsGreen),
                        QuizOption("opt_yellow", "Yellow (पीला)", "Sun", "🟡", listOf("yellow", "peela"), HindiAmber)
                    ),
                    correctOptionId = "opt_green",
                    gentleRetryVoice = "Dekho hara rang pedon jaisa hota hai — Green card tap karo!",
                    praiseVoice = "Superstar! Green yaani hara rang bilkul sahi hai!"
                )
            )
        ),

        // ==================== DRAWING ====================
        TopicUnit(
            id = "draw_tracing",
            subjectId = SubjectId.DRAWING,
            title = "Guided Tracing (A, B, O, 1)",
            hindiTitle = "उंगली से अक्षर लिखना सीखें",
            badgeGlyph = "✏️",
            teacherIntroVoice = "Aaj Drawing mein hum finger se dotted lines par tracing karenge! Bahut maza aayega!",
            revisionVoice = "Wah Little Artist! Aapne bahut sundar tracing ki!",
            items = listOf(
                LessonItem("trace_a", "Trace Letter A", "A", "✏️", "Trace A", "ऊपर से नीचे दो लाइन और बीच में डंडी", "Trace A gently!", "Dotted A ke upar apni pyari finger chalao!", "Shabaash! Apni finger se letter A trace karo!", VisualKind.DRAWING_GUIDE, accentColor = DrawingPurple, tracingGuide = "A"),
                LessonItem("trace_o", "Trace Circle O", "O", "⭕", "Trace Circle", "गोल गोल घुमाओ", "Round and Round!", "Gol ghumakar sundar Circle O banao!", "Bilkul gol circle trace karne ki koshish karo!", VisualKind.DRAWING_GUIDE, accentColor = EnglishPink, tracingGuide = "O")
            ),
            questions = emptyList(),
            drawingMode = DrawingMode.TRACE_GUIDE,
            tracingTargets = listOf("A", "B", "O", "1")
        ),
        TopicUnit(
            id = "draw_coloring",
            subjectId = SubjectId.DRAWING,
            title = "Colouring & Free Drawing",
            hindiTitle = "रंग भरो और चित्र बनाओ",
            badgeGlyph = "🎨",
            teacherIntroVoice = "Chalo aaj hum colourful crayons se Apple aur Sun mein rang bharenge aur apni drawing banayenge!",
            revisionVoice = "Wow! Aap toh ekdum chhote Picasso ho! Bahut pyare rang bhare!",
            items = listOf(
                LessonItem("color_studio", "Magic Colouring Pad", "🎨", "🍎", "Colour & Draw", "मनपसंद रंग चुनो और भरो", "Pick a Bright Colour!", "Neeche se apna favourite colour chuno aur picture par finger chalao!", "Apple, Sun ya Butterfly mein pyaare rang bharo!", VisualKind.DRAWING_GUIDE, accentColor = DrawingPurple)
            ),
            questions = emptyList(),
            drawingMode = DrawingMode.COLORING_BOOK
        )
    )

    val rhymes: List<RhymeItem> = listOf(
        RhymeItem(
            id = "rhyme_twinkle",
            title = "Twinkle Twinkle Little Star",
            hindiSubtitle = "चमकते तारे की कविता",
            badgeGlyph = "🌟",
            color = HindiAmber,
            lyrics = listOf(
                "Twinkle, twinkle, little star,",
                "How I wonder what you are!",
                "Up above the world so high,",
                "Like a diamond in the sky!"
            ),
            melodyNotes = listOf(
                261.63f to 360, 261.63f to 360, 392.00f to 360, 392.00f to 360,
                440.00f to 360, 440.00f to 360, 392.00f to 650,
                349.23f to 360, 349.23f to 360, 329.63f to 360, 329.63f to 360,
                293.66f to 360, 293.66f to 360, 261.63f to 700
            )
        ),
        RhymeItem(
            id = "rhyme_abc",
            title = "ABC Phonics Song",
            hindiSubtitle = "अंग्रेजी अक्षर गीत",
            badgeGlyph = "🎵",
            color = EnglishPink,
            lyrics = listOf(
                "A B C D E F G,",
                "H I J K L M N O P!",
                "Q R S and T U V,",
                "W X Y and Z — Hooray!"
            ),
            melodyNotes = listOf(
                261.63f to 340, 261.63f to 340, 392.00f to 340, 392.00f to 340,
                440.00f to 340, 440.00f to 340, 392.00f to 620,
                349.23f to 320, 349.23f to 320, 329.63f to 320, 329.63f to 320,
                293.66f to 240, 293.66f to 240, 293.66f to 240, 293.66f to 240, 261.63f to 650
            )
        ),
        RhymeItem(
            id = "rhyme_machli",
            title = "मछली जल की रानी है",
            hindiSubtitle = "Machli Jal Ki Rani Hai",
            badgeGlyph = "🐟",
            color = MathsBlue,
            lyrics = listOf(
                "मछली जल की रानी है,",
                "जीवन उसका पानी है।",
                "हाथ लगाओ तो डर जाएगी,",
                "बाहर निकालो तो मर जाएगी!"
            ),
            melodyNotes = listOf(
                329.63f to 320, 349.23f to 320, 392.00f to 320, 392.00f to 480,
                440.00f to 320, 392.00f to 320, 349.23f to 320, 329.63f to 520,
                293.66f to 320, 329.63f to 320, 349.23f to 320, 329.63f to 480,
                293.66f to 320, 261.63f to 650
            )
        ),
        RhymeItem(
            id = "rhyme_numbers",
            title = "1, 2, Buckle My Shoe",
            hindiSubtitle = "गिनती वाला मजेदार गाना",
            badgeGlyph = "👟",
            color = EvsGreen,
            lyrics = listOf(
                "1, 2, Buckle my shoe,",
                "3, 4, Shut the door!",
                "5, 6, Pick up sticks,",
                "7, 8, Lay them straight, 9, 10, A big fat hen!"
            ),
            melodyNotes = listOf(
                261.63f to 300, 293.66f to 300, 329.63f to 280, 349.23f to 280, 392.00f to 520,
                392.00f to 300, 349.23f to 300, 329.63f to 280, 293.66f to 280, 261.63f to 520,
                329.63f to 300, 392.00f to 300, 440.00f to 320, 392.00f to 520
            )
        )
    )

    val memoryPairs: List<MemoryCardItem> = listOf(
        MemoryCardItem("apple", "Apple", "🍎", "A for Apple", EnglishPink),
        MemoryCardItem("mango", "Mango", "🥭", "Aam yaani Mango", HindiAmber),
        MemoryCardItem("lion", "Lion", "🦁", "L for Lion", WarmOrange),
        MemoryCardItem("fish", "Fish", "🐟", "F for Fish", MathsBlue),
        MemoryCardItem("sun", "Sun", "☀️", "S for Sun", AmberGold),
        MemoryCardItem("star", "Star", "⭐", "Bright Star", GrapePurple)
    )

    val flashCards: List<LessonItem> = allTopics
        .filter { it.drawingMode == DrawingMode.NONE }
        .flatMap { it.items }

    val rewardBadges: List<RewardBadge> = listOf(
        RewardBadge("badge_1", "First Star", "पहला तारा", "⭐", 1, HindiAmber),
        RewardBadge("badge_2", "Super Listener", "अच्छा श्रोता", "🎧", 5, MathsBlue),
        RewardBadge("badge_3", "ABC Champ", "अक्षर चैंपियन", "🔤", 10, EnglishPink),
        RewardBadge("badge_4", "Counting Hero", "गिनती हीरो", "🧮", 18, EvsGreen),
        RewardBadge("badge_5", "Little Artist", "नन्हा कलाकार", "🎨", 25, DrawingPurple),
        RewardBadge("badge_6", "LKG Crown", "LKG का ताज", "👑", 40, GentleAmber)
    )

    fun topicsForSubject(subjectId: SubjectId): List<TopicUnit> =
        allTopics.filter { it.subjectId == subjectId }

    fun topicById(topicId: String): TopicUnit =
        allTopics.firstOrNull { it.id == topicId } ?: allTopics.first()

    fun nextTopicAfter(currentTopicId: String): TopicUnit {
        val index = allTopics.indexOfFirst { it.id == currentTopicId }
        return if (index >= 0 && index + 1 < allTopics.size) {
            allTopics[index + 1]
        } else {
            allTopics.first()
        }
    }
}
