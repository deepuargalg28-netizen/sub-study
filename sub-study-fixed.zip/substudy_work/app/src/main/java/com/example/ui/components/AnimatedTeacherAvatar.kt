package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun AnimatedTeacherAvatar(
    isSpeaking: Boolean,
    isCelebrating: Boolean = false,
    size: Dp = 110.dp,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "teacher_anim")

    val bobOffset by transition.animateFloat(
        initialValue = -3f,
        targetValue = if (isCelebrating) -10f else 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isCelebrating) 360 else 1200,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bob"
    )

    val mouthOpen by transition.animateFloat(
        initialValue = 0.1f,
        targetValue = if (isSpeaking) 1.0f else 0.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 220, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mouth"
    )

    val waveAngle by transition.animateFloat(
        initialValue = -14f,
        targetValue = if (isCelebrating || isSpeaking) 18f else 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 520, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave"
    )

    val blinkPhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3400),
            repeatMode = RepeatMode.Restart
        ),
        label = "blink"
    )

    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val yShift = bobOffset * (h / 120f)

        // Soft circular stage backdrop behind teacher
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFFF8E1), Color(0xFFFFE082).copy(alpha = 0.6f))
            ),
            radius = w * 0.46f,
            center = Offset(w * 0.5f, h * 0.52f)
        )

        // Hair Back
        drawCircle(
            color = Color(0xFF4E342E),
            radius = w * 0.27f,
            center = Offset(w * 0.5f, h * 0.36f + yShift)
        )
        // Side Pigtails / Ponytail Accent
        drawCircle(
            color = Color(0xFF3E2723),
            radius = w * 0.11f,
            center = Offset(w * 0.24f, h * 0.36f + yShift)
        )
        drawCircle(
            color = Color(0xFF3E2723),
            radius = w * 0.11f,
            center = Offset(w * 0.76f, h * 0.36f + yShift)
        )
        // Cute Pink Hair Ribbons
        drawCircle(
            color = Color(0xFFEC4899),
            radius = w * 0.048f,
            center = Offset(w * 0.28f, h * 0.30f + yShift)
        )
        drawCircle(
            color = Color(0xFFEC4899),
            radius = w * 0.048f,
            center = Offset(w * 0.72f, h * 0.30f + yShift)
        )

        // Shoulders / Dress Torso (Cheerful Teal-Blue Uniform)
        val bodyPath = Path().apply {
            moveTo(w * 0.26f, h * 0.92f)
            quadraticBezierTo(w * 0.30f, h * 0.62f + yShift, w * 0.50f, h * 0.62f + yShift)
            quadraticBezierTo(w * 0.70f, h * 0.62f + yShift, w * 0.74f, h * 0.92f)
            close()
        }
        drawPath(bodyPath, color = Color(0xFF2563EB))

        // White Collar
        val collarPath = Path().apply {
            moveTo(w * 0.40f, h * 0.64f + yShift)
            lineTo(w * 0.50f, h * 0.73f + yShift)
            lineTo(w * 0.60f, h * 0.64f + yShift)
            close()
        }
        drawPath(collarPath, color = Color.White)

        // Star Teacher Badge on Chest
        drawCircle(
            color = Color(0xFFFFD54F),
            radius = w * 0.055f,
            center = Offset(w * 0.60f, h * 0.77f + yShift)
        )

        // Waving Right Arm
        rotate(
            degrees = waveAngle,
            pivot = Offset(w * 0.70f, h * 0.68f + yShift)
        ) {
            drawLine(
                color = Color(0xFFFFCCBC),
                start = Offset(w * 0.70f, h * 0.68f + yShift),
                end = Offset(w * 0.87f, h * 0.53f + yShift),
                strokeWidth = w * 0.075f,
                cap = StrokeCap.Round
            )
            // Friendly Hand
            drawCircle(
                color = Color(0xFFFFCCBC),
                radius = w * 0.05f,
                center = Offset(w * 0.88f, h * 0.52f + yShift)
            )
        }

        // Left Arm holding cute Book
        drawLine(
            color = Color(0xFFFFCCBC),
            start = Offset(w * 0.30f, h * 0.68f + yShift),
            end = Offset(w * 0.19f, h * 0.76f + yShift),
            strokeWidth = w * 0.075f,
            cap = StrokeCap.Round
        )
        drawRoundRect(
            color = Color(0xFFF43F5E),
            topLeft = Offset(w * 0.11f, h * 0.68f + yShift),
            size = Size(w * 0.14f, h * 0.16f),
            cornerRadius = CornerRadius(8f, 8f)
        )

        // Neck
        drawRoundRect(
            color = Color(0xFFFDBA74).copy(alpha = 0.55f),
            topLeft = Offset(w * 0.45f, h * 0.56f + yShift),
            size = Size(w * 0.10f, h * 0.09f),
            cornerRadius = CornerRadius(8f, 8f)
        )

        // Head / Face
        drawCircle(
            color = Color(0xFFFFD7BA),
            radius = w * 0.22f,
            center = Offset(w * 0.50f, h * 0.40f + yShift)
        )

        // Hair Bangs
        val bangsPath = Path().apply {
            moveTo(w * 0.29f, h * 0.36f + yShift)
            quadraticBezierTo(w * 0.38f, h * 0.21f + yShift, w * 0.50f, h * 0.24f + yShift)
            quadraticBezierTo(w * 0.62f, h * 0.21f + yShift, w * 0.71f, h * 0.36f + yShift)
            quadraticBezierTo(w * 0.60f, h * 0.28f + yShift, w * 0.50f, h * 0.30f + yShift)
            quadraticBezierTo(w * 0.40f, h * 0.28f + yShift, w * 0.29f, h * 0.36f + yShift)
            close()
        }
        drawPath(bangsPath, color = Color(0xFF4E342E))

        // Rosy Cheeks
        drawCircle(
            color = Color(0xFFFB7185).copy(alpha = 0.45f),
            radius = w * 0.042f,
            center = Offset(w * 0.36f, h * 0.44f + yShift)
        )
        drawCircle(
            color = Color(0xFFFB7185).copy(alpha = 0.45f),
            radius = w * 0.042f,
            center = Offset(w * 0.64f, h * 0.44f + yShift)
        )

        // Eyes (Blink briefly near end of cycle)
        val isBlinking = blinkPhase > 0.94f
        if (isBlinking) {
            drawLine(
                color = Color(0xFF1E293B),
                start = Offset(w * 0.38f, h * 0.38f + yShift),
                end = Offset(w * 0.44f, h * 0.38f + yShift),
                strokeWidth = 4f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = Color(0xFF1E293B),
                start = Offset(w * 0.56f, h * 0.38f + yShift),
                end = Offset(w * 0.62f, h * 0.38f + yShift),
                strokeWidth = 4f,
                cap = StrokeCap.Round
            )
        } else {
            // Left Eye
            drawCircle(Color(0xFF1E293B), radius = w * 0.032f, center = Offset(w * 0.41f, h * 0.38f + yShift))
            drawCircle(Color.White, radius = w * 0.011f, center = Offset(w * 0.418f, h * 0.372f + yShift))
            // Right Eye
            drawCircle(Color(0xFF1E293B), radius = w * 0.032f, center = Offset(w * 0.59f, h * 0.38f + yShift))
            drawCircle(Color.White, radius = w * 0.011f, center = Offset(w * 0.598f, h * 0.372f + yShift))
        }

        // Lip-sync Animated Smile Mouth
        if (isSpeaking) {
            val openH = w * (0.025f + mouthOpen * 0.045f)
            drawOval(
                color = Color(0xFFBE123C),
                topLeft = Offset(w * 0.445f, h * 0.46f + yShift),
                size = Size(w * 0.11f, openH)
            )
        } else {
            val smilePath = Path().apply {
                moveTo(w * 0.43f, h * 0.465f + yShift)
                quadraticBezierTo(w * 0.50f, h * 0.515f + yShift, w * 0.57f, h * 0.465f + yShift)
            }
            drawPath(
                path = smilePath,
                color = Color(0xFF9F1239),
                style = Stroke(width = 4.5f, cap = StrokeCap.Round)
            )
        }
    }
}
