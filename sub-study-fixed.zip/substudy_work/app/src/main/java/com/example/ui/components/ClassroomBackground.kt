package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import com.example.ui.theme.MeadowDark
import com.example.ui.theme.MeadowLight
import com.example.ui.theme.SkyBottom
import com.example.ui.theme.SkyTop
import com.example.ui.theme.SunGold

@Composable
fun ClassroomBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "classroom_bg")
    val cloudDrift by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 16000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cloud_drift"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(SkyTop, SkyBottom, Color(0xFFE0F7FA), MeadowLight.copy(alpha = 0.45f))
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Warm Sunshine Glow in top-right
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(SunGold.copy(alpha = 0.55f), SunGold.copy(alpha = 0.0f)),
                    center = Offset(w * 0.88f, h * 0.09f),
                    radius = w * 0.36f
                ),
                radius = w * 0.36f,
                center = Offset(w * 0.88f, h * 0.09f)
            )
            drawCircle(
                color = SunGold.copy(alpha = 0.85f),
                radius = w * 0.08f,
                center = Offset(w * 0.88f, h * 0.09f)
            )

            // Soft Drifting Clouds
            val cloudX1 = w * (0.15f + cloudDrift * 0.14f)
            val cloudY1 = h * 0.12f
            drawCloud(Offset(cloudX1, cloudY1), w * 0.14f)

            val cloudX2 = w * (0.72f - cloudDrift * 0.12f)
            val cloudY2 = h * 0.18f
            drawCloud(Offset(cloudX2, cloudY2), w * 0.11f)

            // Rolling Green Meadow Hills at bottom
            val backHill = Path().apply {
                moveTo(0f, h * 0.86f)
                quadraticBezierTo(w * 0.28f, h * 0.78f, w * 0.58f, h * 0.85f)
                quadraticBezierTo(w * 0.82f, h * 0.90f, w, h * 0.83f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(backHill, color = MeadowLight.copy(alpha = 0.7f))

            val frontHill = Path().apply {
                moveTo(0f, h * 0.91f)
                quadraticBezierTo(w * 0.35f, h * 0.86f, w * 0.70f, h * 0.92f)
                quadraticBezierTo(w * 0.88f, h * 0.95f, w, h * 0.89f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(frontHill, color = MeadowDark.copy(alpha = 0.35f))

            // Cheerful Meadow Flowers
            val flowerColors = listOf(Color(0xFFF472B6), Color(0xFFFACC15), Color(0xFFFFFFFF))
            for (i in 0..5) {
                val fx = w * (0.08f + i * 0.17f)
                val fy = h * (0.93f + (i % 2) * 0.025f)
                drawCircle(
                    color = flowerColors[i % flowerColors.size].copy(alpha = 0.65f),
                    radius = 7f,
                    center = Offset(fx, fy)
                )
            }
        }
        content()
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCloud(
    center: Offset,
    baseRadius: Float
) {
    val cloudColor = Color.White.copy(alpha = 0.62f)
    drawCircle(cloudColor, radius = baseRadius * 0.72f, center = Offset(center.x - baseRadius * 0.65f, center.y + baseRadius * 0.15f))
    drawCircle(cloudColor, radius = baseRadius, center = center)
    drawCircle(cloudColor, radius = baseRadius * 0.76f, center = Offset(center.x + baseRadius * 0.68f, center.y + baseRadius * 0.12f))
    drawRect(
        color = cloudColor,
        topLeft = Offset(center.x - baseRadius * 0.75f, center.y + baseRadius * 0.05f),
        size = Size(baseRadius * 1.5f, baseRadius * 0.78f)
    )
}
