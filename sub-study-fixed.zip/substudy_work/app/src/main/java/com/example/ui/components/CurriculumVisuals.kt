package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LessonItem
import com.example.data.model.VisualKind
import com.example.ui.theme.EnglishPink
import com.example.ui.theme.EvsGreen
import com.example.ui.theme.HindiAmber
import com.example.ui.theme.InkNavy
import com.example.ui.theme.MathsBlue
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Tactile 3D-styled toy-block card with a crisp bottom depth rim and minimum touch target.
 */
@Composable
fun Tactile3DCard(
    containerColor: Color,
    lipColor: Color,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .shadow(elevation = 6.dp, shape = shape, clip = false)
            .clip(shape)
            .background(lipColor)
            .padding(bottom = 5.dp)
            .clip(shape)
            .background(containerColor)
            .then(
                if (onClick != null) {
                    Modifier
                        .minimumInteractiveComponentSize()
                        .clickable(onClick = onClick)
                } else {
                    Modifier
                }
            )
    ) {
        content()
    }
}

@Composable
fun ConfettiBurstOverlay(
    visible: Boolean,
    modifier: Modifier = Modifier
) {
    if (!visible) return
    val transition = rememberInfiniteTransition(label = "confetti")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "confetti_fall"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val colors = listOf(
            Color(0xFFF43F5E),
            Color(0xFFFACC15),
            Color(0xFF38BDF8),
            Color(0xFF4ADE80),
            Color(0xFFA855F7),
            Color(0xFFFF7043)
        )
        for (i in 0 until 28) {
            val angle = (i * 37) % 360
            val rad = angle * PI / 180.0
            val xBase = size.width * ((i * 19 % 100) / 100f)
            val yPos = (size.height * 0.1f) + ((progress + (i % 5) * 0.15f) % 1f) * size.height * 0.85f
            val xOffset = (cos(rad + progress * 6f) * 24f).toFloat()
            drawCircle(
                color = colors[i % colors.size].copy(alpha = 0.9f),
                radius = if (i % 2 == 0) 11f else 7f,
                center = Offset((xBase + xOffset).coerceIn(0f, size.width), yPos)
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LessonIllustrationStage(
    item: LessonItem,
    pulseCount: Int,
    modifier: Modifier = Modifier
) {
    val pulseScale by animateFloatAsState(
        targetValue = if (pulseCount % 2 == 1) 1.05f else 1.0f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 350f),
        label = "item_pulse"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "stage_float")
    val floatY by infiniteTransition.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "float_y"
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .scale(pulseScale),
        shape = RoundedCornerShape(28.dp),
        color = PureWhite,
        border = BorderStroke(3.dp, item.accentColor.copy(alpha = 0.45f)),
        shadowElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(item.accentColor.copy(alpha = 0.10f), PureWhite)
                    )
                )
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            when (item.visualKind) {
                VisualKind.NUMBER_COUNT -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(92.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(item.accentColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = item.displayGlyph,
                                style = MaterialTheme.typography.displayLarge.copy(
                                    fontSize = if (item.displayGlyph.length > 2) 34.sp else 48.sp
                                ),
                                color = PureWhite
                            )
                        }
                        Spacer(modifier = Modifier.width(18.dp))
                        FlowRow(
                            maxItemsInEachRow = 5,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            repeat(item.countValue.coerceIn(1, 10)) {
                                Text(
                                    text = item.subGlyph,
                                    fontSize = 34.sp
                                )
                            }
                        }
                    }
                }

                VisualKind.SHAPE_CARD -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Canvas(modifier = Modifier.size(104.dp)) {
                            val cx = size.width / 2f
                            val cy = size.height / 2f + floatY
                            when {
                                item.id.contains("circle") -> {
                                    drawCircle(
                                        color = item.accentColor,
                                        radius = size.minDimension * 0.42f,
                                        center = Offset(cx, cy)
                                    )
                                    drawCircle(
                                        color = Color.White.copy(alpha = 0.35f),
                                        radius = size.minDimension * 0.16f,
                                        center = Offset(cx - 16f, cy - 16f)
                                    )
                                }
                                item.id.contains("square") -> {
                                    val side = size.minDimension * 0.72f
                                    drawRoundRect(
                                        color = item.accentColor,
                                        topLeft = Offset(cx - side / 2f, cy - side / 2f),
                                        size = androidx.compose.ui.geometry.Size(side, side),
                                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f, 18f)
                                    )
                                }
                                else -> {
                                    val path = Path().apply {
                                        moveTo(cx, cy - size.height * 0.38f)
                                        lineTo(cx + size.width * 0.38f, cy + size.height * 0.32f)
                                        lineTo(cx - size.width * 0.38f, cy + size.height * 0.32f)
                                        close()
                                    }
                                    drawPath(path, color = item.accentColor)
                                    drawPath(path, color = InkNavy.copy(alpha = 0.15f), style = Stroke(width = 6f))
                                }
                            }
                        }
                        Spacer(modifier = Modifier.width(18.dp))
                        Text(text = item.subGlyph, fontSize = 54.sp)
                    }
                }

                VisualKind.COLOR_SPLASH -> {
                    Box(
                        modifier = Modifier
                            .size(112.dp)
                            .clip(CircleShape)
                            .background(item.accentColor)
                            .border(5.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = item.subGlyph, fontSize = 48.sp)
                    }
                }

                else -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(98.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(item.accentColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = item.displayGlyph,
                                style = MaterialTheme.typography.displayLarge.copy(
                                    fontSize = if (item.displayGlyph.length > 2) 30.sp else 48.sp
                                ),
                                color = PureWhite,
                                textAlign = TextAlign.Center
                            )
                        }
                        Spacer(modifier = Modifier.width(20.dp))
                        Text(
                            text = item.subGlyph,
                            fontSize = 68.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = item.englishWord,
                style = MaterialTheme.typography.headlineLarge,
                color = InkNavy,
                textAlign = TextAlign.Center
            )
            Text(
                text = "${item.hindiHint}  •  ${item.phonicsText}",
                style = MaterialTheme.typography.titleMedium,
                color = item.accentColor,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
    }
}
