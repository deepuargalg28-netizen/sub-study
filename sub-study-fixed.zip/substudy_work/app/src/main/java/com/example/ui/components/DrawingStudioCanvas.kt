package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DrawingMode
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.DrawingPurple
import com.example.ui.theme.EnglishPink
import com.example.ui.theme.EvsGreen
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.HindiAmber
import com.example.ui.theme.InkNavy
import com.example.ui.theme.MathsBlue
import com.example.ui.theme.PureWhite
import com.example.ui.theme.WarmOrange

private data class DrawStroke(
    val points: List<Offset>,
    val color: Color,
    val width: Float
)

@Composable
fun DrawingStudioCanvas(
    mode: DrawingMode,
    tracingTargets: List<String>,
    onStrokeStarted: () -> Unit,
    onDoneDrawing: () -> Unit,
    modifier: Modifier = Modifier
) {
    val paletteColors = listOf(
        EnglishPink,
        MathsBlue,
        HindiAmber,
        EvsGreen,
        DrawingPurple,
        WarmOrange,
        Color(0xFFEF4444),
        InkNavy
    )
    var selectedColor by remember { mutableStateOf(paletteColors.first()) }
    val strokes = remember { mutableStateListOf<DrawStroke>() }
    var activePoints by remember { mutableStateOf<List<Offset>>(emptyList()) }

    val effectiveTargets = if (tracingTargets.isNotEmpty()) tracingTargets else listOf("A", "B", "O", "1")
    var selectedTargetIndex by remember { mutableIntStateOf(0) }
    val coloringTemplates = listOf("🍎 Apple", "☀️ Sun", "🦋 Butterfly", "✨ Free")
    var selectedTemplateIndex by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Target / Template Switcher
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (mode == DrawingMode.TRACE_GUIDE) {
                effectiveTargets.forEachIndexed { idx, target ->
                    FilterChip(
                        selected = idx == selectedTargetIndex,
                        onClick = {
                            selectedTargetIndex = idx
                            strokes.clear()
                        },
                        label = { Text("Trace $target", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    )
                }
            } else {
                coloringTemplates.forEachIndexed { idx, label ->
                    FilterChip(
                        selected = idx == selectedTemplateIndex,
                        onClick = {
                            selectedTemplateIndex = idx
                            strokes.clear()
                        },
                        label = { Text(label) },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    )
                }
            }
        }

        // Interactive Canvas Board
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(270.dp),
            shape = RoundedCornerShape(28.dp),
            color = PureWhite,
            border = BorderStroke(3.dp, DrawingPurple.copy(alpha = 0.45f)),
            shadowElevation = 6.dp
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Ghost guide under drawing strokes
                if (mode == DrawingMode.TRACE_GUIDE) {
                    Text(
                        text = effectiveTargets[selectedTargetIndex],
                        fontSize = 185.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFCBD5E1).copy(alpha = 0.7f),
                        modifier = Modifier.align(Alignment.Center)
                    )
                } else {
                    when (selectedTemplateIndex) {
                        0 -> Text("🍎", fontSize = 150.sp, modifier = Modifier.align(Alignment.Center))
                        1 -> Text("☀️", fontSize = 150.sp, modifier = Modifier.align(Alignment.Center))
                        2 -> Text("🦋", fontSize = 150.sp, modifier = Modifier.align(Alignment.Center))
                        else -> Unit
                    }
                }

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("drawing_canvas")
                        .pointerInput(selectedColor) {
                            detectDragGestures(
                                onDragStart = { startOffset ->
                                    onStrokeStarted()
                                    activePoints = listOf(startOffset)
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    activePoints = activePoints + change.position
                                },
                                onDragEnd = {
                                    if (activePoints.isNotEmpty()) {
                                        strokes.add(
                                            DrawStroke(
                                                points = activePoints,
                                                color = selectedColor,
                                                width = 22f
                                            )
                                        )
                                        activePoints = emptyList()
                                    }
                                },
                                onDragCancel = {
                                    activePoints = emptyList()
                                }
                            )
                        }
                ) {
                    val drawStrokePath: (List<Offset>, Color, Float) -> Unit = { pts, color, w ->
                        if (pts.size == 1) {
                            drawCircle(color = color, radius = w / 2f, center = pts.first())
                        } else if (pts.size > 1) {
                            val path = Path().apply {
                                moveTo(pts.first().x, pts.first().y)
                                for (i in 1 until pts.size) {
                                    lineTo(pts[i].x, pts[i].y)
                                }
                            }
                            drawPath(
                                path = path,
                                color = color,
                                style = Stroke(
                                    width = w,
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round
                                )
                            )
                        }
                    }

                    strokes.forEach { stroke ->
                        drawStrokePath(stroke.points, stroke.color, stroke.width)
                    }
                    if (activePoints.isNotEmpty()) {
                        drawStrokePath(activePoints, selectedColor, 22f)
                    }
                }
            }
        }

        // Color Bubbles & Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                paletteColors.forEach { color ->
                    val isSelected = color == selectedColor
                    Box(
                        modifier = Modifier
                            .size(if (isSelected) 38.dp else 32.dp)
                            .clip(CircleShape)
                            .background(color)
                            .border(
                                width = if (isSelected) 3.dp else 1.5.dp,
                                color = if (isSelected) InkNavy else PureWhite,
                                shape = CircleShape
                            )
                            .clickable { selectedColor = color }
                    )
                }
            }

            Row {
                IconButton(
                    onClick = { if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex) },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Rounded.Undo, contentDescription = "Undo Stroke", tint = BrandBlue)
                }
                IconButton(
                    onClick = { strokes.clear() },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Rounded.Delete, contentDescription = "Clear Canvas", tint = WarmOrange)
                }
            }
        }

        Button(
            onClick = onDoneDrawing,
            shape = RoundedCornerShape(50),
            colors = ButtonDefaults.buttonColors(containerColor = FreshGreen),
            modifier = Modifier
                .fillMaxWidth()
                .minimumInteractiveComponentSize()
                .testTag("finish_drawing_button")
        ) {
            Icon(Icons.Rounded.Check, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Done! Get My Stars ⭐",
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}
