package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.InkNavy
import com.example.ui.theme.WarmOrange
import kotlin.random.Random

@Composable
fun ParentGateDialog(
    title: String,
    subtitle: String,
    expectedPin: String,
    onDismiss: () -> Unit,
    onUnlocked: () -> Unit
) {
    val numA = remember { Random.nextInt(4, 10) }
    val numB = remember { Random.nextInt(3, 9) }
    val expectedSum = numA + numB

    var input by remember { mutableStateOf("") }
    var usePinMode by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        icon = {
            Icon(
                imageVector = Icons.Rounded.Lock,
                contentDescription = "Parent Gate",
                tint = BrandBlue
            )
        },
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = InkNavy
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium
                )
                if (usePinMode) {
                    Text(
                        text = "Enter 4-digit Parent PIN (Default: 1234)",
                        style = MaterialTheme.typography.labelSmall,
                        color = BrandBlue
                    )
                } else {
                    Text(
                        text = "Parents Only: What is $numA + $numB ?",
                        style = MaterialTheme.typography.titleMedium,
                        color = BrandBlue
                    )
                }

                OutlinedTextField(
                    value = input,
                    onValueChange = {
                        if (it.length <= 6) {
                            input = it.filter { ch -> ch.isDigit() }
                            errorMessage = null
                        }
                    },
                    singleLine = true,
                    label = { Text(if (usePinMode) "Parent PIN" else "Answer") },
                    visualTransformation = if (usePinMode) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("parent_gate_input")
                )

                errorMessage?.let {
                    Text(
                        text = it,
                        color = WarmOrange,
                        style = MaterialTheme.typography.labelSmall
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = {
                            usePinMode = !usePinMode
                            input = ""
                            errorMessage = null
                        }
                    ) {
                        Text(if (usePinMode) "Use Math Check" else "Use Parent PIN")
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val unlocked = if (usePinMode) {
                        input == expectedPin
                    } else {
                        input.toIntOrNull() == expectedSum || input == expectedPin
                    }
                    if (unlocked) {
                        onUnlocked()
                    } else {
                        errorMessage = "Incorrect answer. Please try again."
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                modifier = Modifier.testTag("parent_gate_unlock_button")
            ) {
                Text("Unlock")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Back to Kids")
            }
        }
    )
}
