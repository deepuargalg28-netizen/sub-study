package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LkgCurriculumRepository
import com.example.data.model.MemoryCardItem
import com.example.ui.components.ConfettiBurstOverlay
import com.example.ui.components.LessonIllustrationStage
import com.example.ui.components.Tactile3DCard
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.DrawingPurple
import com.example.ui.theme.EnglishPink
import com.example.ui.theme.EvsGreen
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.HindiAmber
import com.example.ui.theme.InkNavy
import com.example.ui.theme.MathsBlue
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SunnyYellow
import com.example.ui.theme.WarmOrange
import kotlinx.coroutines.delay

@Composable
fun GamesScreen(
    initialActivity: FunActivityKind,
    totalStars: Int,
    activeRhymeLineIndex: Int,
    onSpeak: (String) -> Unit,
    onTapSound: () -> Unit,
    onPlayRhyme: (lyrics: List<String>, notes: List<Pair<Float, Int>>, title: String, onDone: () -> Unit) -> Unit,
    onStopRhyme: () -> Unit,
    onAwardStars: (Int, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember(initialActivity) { mutableStateOf(initialActivity) }

    DisposableEffect(Unit) {
        onDispose { onStopRhyme() }
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 900.dp)
                .align(Alignment.TopCenter),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Fun Learning & Games",
                        style = MaterialTheme.typography.headlineLarge,
                        color = InkNavy
                    )
                    Text(
                        text = "Khelo, Gao aur Stars Jeeto!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SlateMuted
                    )
                }
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(FunActivityKind.entries) { kind ->
                        FilterChip(
                            selected = selectedTab == kind,
                            onClick = {
                                onTapSound()
                                onStopRhyme()
                                selectedTab = kind
                            },
                            label = { Text("${kind.glyph} ${kind.title}") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BrandIndigo,
                                selectedLabelColor = PureWhite,
                                containerColor = PureWhite
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("game_tab_${kind.name.lowercase()}")
                        )
                    }
                }
            }

            item {
                when (selectedTab) {
                    FunActivityKind.MEMORY_GAMES -> MemoryMatchBoard(
                        onSpeak = onSpeak,
                        onTapSound = onTapSound,
                        onWon = { onAwardStars(4, "Memory Match Champion") }
                    )
                    FunActivityKind.RHYMES_SONGS -> RhymesPlayerPanel(
                        activeLineIndex = activeRhymeLineIndex,
                        onPlayRhyme = onPlayRhyme,
                        onStopRhyme = onStopRhyme
                    )
                    FunActivityKind.FLASH_CARDS -> FlashCardsPanel(
                        onSpeak = onSpeak,
                        onTapSound = onTapSound
                    )
                    FunActivityKind.QUIZ_TIME -> QuickQuizPanel(
                        onSpeak = onSpeak,
                        onAwardStars = onAwardStars
                    )
                    FunActivityKind.REWARD_TIME -> RewardBoxPanel(
                        totalStars = totalStars,
                        onSpeak = onSpeak
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

private data class MemorySlot(
    val uid: Int,
    val item: MemoryCardItem,
    val isFaceUp: Boolean = false,
    val isMatched: Boolean = false
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MemoryMatchBoard(
    onSpeak: (String) -> Unit,
    onTapSound: () -> Unit,
    onWon: () -> Unit
) {
    fun buildDeck(): List<MemorySlot> {
        val pairs = LkgCurriculumRepository.memoryPairs
        val doubled = (pairs + pairs).shuffled()
        return doubled.mapIndexed { index, card -> MemorySlot(uid = index, item = card) }
    }

    var deck by remember { mutableStateOf(buildDeck()) }
    var firstIndex by remember { mutableStateOf<Int?>(null) }
    var secondIndex by remember { mutableStateOf<Int?>(null) }
    var isBusy by remember { mutableStateOf(false) }
    var wonGame by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        onSpeak("Chalo Memory Match khelein! Same-same pictures ko match karo!")
    }

    LaunchedEffect(secondIndex) {
        val i1 = firstIndex
        val i2 = secondIndex
        if (i1 != null && i2 != null) {
            isBusy = true
            delay(650L)
            val c1 = deck[i1]
            val c2 = deck[i2]
            if (c1.item.pairId == c2.item.pairId) {
                deck = deck.mapIndexed { idx, slot ->
                    if (idx == i1 || idx == i2) slot.copy(isMatched = true, isFaceUp = true) else slot
                }
                onSpeak("Waah! ${c1.item.spokenWord} match ho gaya!")
                if (deck.all { it.isMatched }) {
                    wonGame = true
                    onWon()
                }
            } else {
                deck = deck.mapIndexed { idx, slot ->
                    if (idx == i1 || idx == i2) slot.copy(isFaceUp = false) else slot
                }
            }
            firstIndex = null
            secondIndex = null
            isBusy = false
        }
    }

    Box(modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Match Same Pairs!",
                    style = MaterialTheme.typography.titleLarge,
                    color = InkNavy
                )
                OutlinedButton(
                    onClick = {
                        onTapSound()
                        deck = buildDeck()
                        firstIndex = null
                        secondIndex = null
                        wonGame = false
                    },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Rounded.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Game")
                }
            }

            AnimatedVisibility(visible = wonGame) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Color(0xFFDCFCE7),
                    border = BorderStroke(2.dp, FreshGreen),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "🎉 Shabaash! All Pairs Matched! +4 Stars Earned! ⭐",
                        style = MaterialTheme.typography.titleMedium,
                        color = FreshGreen,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                maxItemsInEachRow = 3,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                deck.forEachIndexed { idx, slot ->
                    val revealed = slot.isFaceUp || slot.isMatched
                    Tactile3DCard(
                        containerColor = when {
                            slot.isMatched -> Color(0xFFDCFCE7)
                            revealed -> PureWhite
                            else -> BrandBlue
                        },
                        lipColor = when {
                            slot.isMatched -> FreshGreen
                            revealed -> slot.item.color
                            else -> Color(0xFF1E3A8A)
                        },
                        cornerRadius = 20.dp,
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .testTag("memory_card_$idx"),
                        onClick = {
                            if (!isBusy && !revealed && !wonGame) {
                                onTapSound()
                                deck = deck.mapIndexed { i, s -> if (i == idx) s.copy(isFaceUp = true) else s }
                                if (firstIndex == null) {
                                    firstIndex = idx
                                } else {
                                    secondIndex = idx
                                }
                            }
                        }
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            if (revealed) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = slot.item.glyph, fontSize = 36.sp)
                                    Text(
                                        text = slot.item.title,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = InkNavy
                                    )
                                }
                            } else {
                                Text(text = "⭐", fontSize = 34.sp)
                            }
                        }
                    }
                }
            }
        }
        ConfettiBurstOverlay(visible = wonGame)
    }
}

@Composable
private fun RhymesPlayerPanel(
    activeLineIndex: Int,
    onPlayRhyme: (lyrics: List<String>, notes: List<Pair<Float, Int>>, title: String, onDone: () -> Unit) -> Unit,
    onStopRhyme: () -> Unit
) {
    var playingRhymeId by remember { mutableStateOf<String?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LkgCurriculumRepository.rhymes.forEach { rhyme ->
            val isPlaying = playingRhymeId == rhyme.id
            Tactile3DCard(
                containerColor = PureWhite,
                lipColor = rhyme.color,
                cornerRadius = 24.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = rhyme.color.copy(alpha = 0.18f),
                                modifier = Modifier.size(54.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(text = rhyme.badgeGlyph, fontSize = 28.sp)
                                }
                            }
                            Column {
                                Text(
                                    text = rhyme.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = InkNavy
                                )
                                Text(
                                    text = rhyme.hindiSubtitle,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SlateMuted
                                )
                            }
                        }

                        Button(
                            onClick = {
                                if (isPlaying) {
                                    onStopRhyme()
                                    playingRhymeId = null
                                } else {
                                    playingRhymeId = rhyme.id
                                    onPlayRhyme(rhyme.lyrics, rhyme.melodyNotes, rhyme.title) {
                                        playingRhymeId = null
                                    }
                                }
                            },
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPlaying) WarmOrange else rhyme.color
                            ),
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Rounded.Stop else Icons.Rounded.MusicNote,
                                contentDescription = if (isPlaying) "Stop Song" else "Play Song"
                            )
                        }
                    }

                    // Karaoke Lyrics
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        rhyme.lyrics.forEachIndexed { idx, line ->
                            val highlighted = isPlaying && idx == activeLineIndex
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (highlighted) SunnyYellow.copy(alpha = 0.45f) else Color.Transparent
                            ) {
                                Text(
                                    text = line,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = if (highlighted) FontWeight.Bold else FontWeight.Medium,
                                    color = if (highlighted) BrandIndigo else SlateMuted,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FlashCardsPanel(
    onSpeak: (String) -> Unit,
    onTapSound: () -> Unit
) {
    val cards = remember { LkgCurriculumRepository.flashCards }
    var currentIndex by remember { mutableIntStateOf(0) }
    var autoPlaying by remember { mutableStateOf(false) }

    val card = cards[currentIndex]

    LaunchedEffect(currentIndex, autoPlaying) {
        onSpeak("${card.title}. ${card.phonicsText}")
        if (autoPlaying) {
            delay(3600L)
            currentIndex = (currentIndex + 1) % cards.size
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Card ${currentIndex + 1} of ${cards.size}",
                style = MaterialTheme.typography.titleMedium,
                color = InkNavy
            )
            Button(
                onClick = { autoPlaying = !autoPlaying },
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (autoPlaying) WarmOrange else FreshGreen
                ),
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(
                    imageVector = if (autoPlaying) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (autoPlaying) "Stop Auto-Flip" else "Auto-Play Cards")
            }
        }

        LessonIllustrationStage(item = card, pulseCount = currentIndex)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = {
                    onTapSound()
                    currentIndex = if (currentIndex == 0) cards.lastIndex else currentIndex - 1
                },
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
            ) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Previous")
            }
            Button(
                onClick = {
                    onTapSound()
                    onSpeak("${card.title}. ${card.teacherExplain}")
                },
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(Icons.Rounded.VolumeUp, contentDescription = "Speak Card")
            }
            Button(
                onClick = {
                    onTapSound()
                    currentIndex = (currentIndex + 1) % cards.size
                },
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(containerColor = card.accentColor),
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
            ) {
                Text("Next")
                Spacer(modifier = Modifier.width(6.dp))
                Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun QuickQuizPanel(
    onSpeak: (String) -> Unit,
    onAwardStars: (Int, String) -> Unit
) {
    val allQuestions = remember { LkgCurriculumRepository.allTopics.flatMap { it.questions } }
    var qIndex by remember { mutableIntStateOf(0) }
    var feedback by remember { mutableStateOf<String?>(null) }
    var showBurst by remember { mutableStateOf(false) }

    val question = allQuestions[qIndex]

    LaunchedEffect(qIndex) {
        feedback = null
        showBurst = false
        onSpeak(question.promptVoice)
    }

    Box(modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = PureWhite,
                border = BorderStroke(2.5.dp, BrandBlue),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Quiz ${qIndex + 1} / ${allQuestions.size}",
                        style = MaterialTheme.typography.labelLarge,
                        color = BrandBlue
                    )
                    Text(
                        text = question.promptText,
                        style = MaterialTheme.typography.headlineMedium,
                        color = InkNavy,
                        textAlign = TextAlign.Center
                    )
                    IconButton(
                        onClick = { onSpeak(question.promptVoice) },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Rounded.VolumeUp, contentDescription = "Repeat Question", tint = BrandBlue)
                    }
                    feedback?.let {
                        Text(
                            text = it,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (showBurst) FreshGreen else WarmOrange,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                maxItemsInEachRow = 3,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                question.options.forEach { opt ->
                    Tactile3DCard(
                        containerColor = PureWhite,
                        lipColor = opt.accentColor,
                        cornerRadius = 22.dp,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            if (opt.id == question.correctOptionId) {
                                showBurst = true
                                feedback = "🌟 Shabaash! +2 Stars!"
                                onSpeak(question.praiseVoice)
                                onAwardStars(2, "Quiz Time Win")
                            } else {
                                showBurst = false
                                feedback = "Koi baat nahi! Phir se try karo!"
                                onSpeak(question.gentleRetryVoice)
                            }
                        }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = opt.glyph, fontSize = 44.sp)
                            Text(
                                text = opt.label,
                                style = MaterialTheme.typography.titleMedium,
                                color = InkNavy,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            Button(
                onClick = { qIndex = (qIndex + 1) % allQuestions.size },
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
            ) {
                Text("Next Quiz Question ▶", style = MaterialTheme.typography.titleMedium)
            }
        }
        ConfettiBurstOverlay(visible = showBurst)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RewardBoxPanel(
    totalStars: Int,
    onSpeak: (String) -> Unit
) {
    LaunchedEffect(Unit) {
        onSpeak("Dekho aapka Reward Box! Aapke paas $totalStars stars hain! Roz padhai karke naye badges unlock karo!")
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = PureWhite,
            border = BorderStroke(2.5.dp, SunnyYellow),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(text = "🎁", fontSize = 44.sp)
                Column {
                    Text(
                        text = "Your Sticker & Trophy Shelf",
                        style = MaterialTheme.typography.titleLarge,
                        color = InkNavy
                    )
                    Text(
                        text = "Total Stars: $totalStars ⭐",
                        style = MaterialTheme.typography.titleMedium,
                        color = AmberGold
                    )
                }
            }
        }

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            maxItemsInEachRow = 2,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LkgCurriculumRepository.rewardBadges.forEach { badge ->
                val unlocked = totalStars >= badge.requiredStars
                Tactile3DCard(
                    containerColor = if (unlocked) PureWhite else Color(0xFFF1F5F9),
                    lipColor = if (unlocked) badge.color else Color(0xFFCBD5E1),
                    cornerRadius = 22.dp,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        if (unlocked) {
                            onSpeak("Wah! Aapne ${badge.title} unlock kar liya hai!")
                        } else {
                            onSpeak("${badge.title} unlock karne ke liye ${badge.requiredStars} stars chahiye!")
                        }
                    }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = badge.glyph,
                                fontSize = 44.sp,
                                color = if (unlocked) Color.Unspecified else Color.Gray
                            )
                            if (!unlocked) {
                                Icon(
                                    imageVector = Icons.Rounded.Lock,
                                    contentDescription = "Locked",
                                    tint = SlateMuted,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Text(
                            text = badge.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (unlocked) InkNavy else SlateMuted,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = if (unlocked) "Unlocked! ⭐" else "Need ${badge.requiredStars} ⭐",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (unlocked) FreshGreen else SlateMuted
                        )
                    }
                }
            }
        }
    }
}
