package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChildProfileEntity
import com.example.data.local.TopicProgressEntity
import com.example.data.model.LkgCurriculumRepository
import com.example.data.model.SubjectId
import com.example.data.model.TopicUnit
import com.example.ui.components.AnimatedTeacherAvatar
import com.example.ui.components.Tactile3DCard
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.ChalkboardFrame
import com.example.ui.theme.ChalkboardGreen
import com.example.ui.theme.DrawingPurple
import com.example.ui.theme.EnglishPink
import com.example.ui.theme.EvsGreen
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.HindiAmber
import com.example.ui.theme.InkNavy
import com.example.ui.theme.MathsBlue
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SunnyYellow
import com.example.ui.theme.WarmOrange

enum class FunActivityKind(
    val title: String,
    val glyph: String,
    val bgColor: Color,
    val lipColor: Color
) {
    MEMORY_GAMES("Memory Game", "🎮", Color(0xFFFCE7F3), Color(0xFFF472B6)),
    RHYMES_SONGS("Rhymes & Songs", "🎵", Color(0xFFE0F2FE), Color(0xFF38BDF8)),
    FLASH_CARDS("Flash Cards", "🃏", Color(0xFFFEF3C7), Color(0xFFFBBF24)),
    QUIZ_TIME("Quiz Time", "🏆", Color(0xFFDCFCE7), Color(0xFF4ADE80)),
    REWARD_TIME("Reward Box", "🎁", Color(0xFFEDE9FE), Color(0xFFA78BFA))
}

@Composable
fun HomeScreen(
    profile: ChildProfileEntity,
    recommendedTopic: TopicUnit,
    topicProgressList: List<TopicProgressEntity>,
    todayProgressFraction: Float,
    isSpeaking: Boolean,
    teacherCaption: String,
    autoplayCountdown: Int?,
    isAutoplayPaused: Boolean,
    isSessionLimitReached: Boolean,
    onContinueLearning: (String) -> Unit,
    onToggleAutoplayPause: () -> Unit,
    onSubjectSelected: (SubjectId) -> Unit,
    onFunActivitySelected: (FunActivityKind) -> Unit,
    onOpenParentSettings: () -> Unit,
    onTapTeacherAvatar: () -> Unit,
    modifier: Modifier = Modifier
) {
    val completedTopicIds = topicProgressList.filter { it.completionsCount > 0 }.map { it.topicId }.toSet()

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isWide = maxWidth >= 640.dp

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 920.dp)
                .align(Alignment.TopCenter),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. HEADER: Sub Study, LKG Badge, Child Profile, Parent Settings
            item {
                HomeTopHeader(
                    profile = profile,
                    onOpenParentSettings = onOpenParentSettings
                )
            }

            // 2. WELCOME BANNER & ANIMATED TEACHER STAGE
            item {
                TeacherHeroStage(
                    childName = profile.childName,
                    recommendedTopic = recommendedTopic,
                    isSpeaking = isSpeaking,
                    teacherCaption = teacherCaption,
                    autoplayCountdown = autoplayCountdown,
                    isAutoplayPaused = isAutoplayPaused,
                    isSessionLimitReached = isSessionLimitReached,
                    isWide = isWide,
                    onContinueLearning = { onContinueLearning(recommendedTopic.id) },
                    onToggleAutoplayPause = onToggleAutoplayPause,
                    onTapTeacher = onTapTeacherAvatar
                )
            }

            // 3. SUBJECTS FOR LKG
            item {
                SectionPillHeader(
                    title = "Subjects for LKG",
                    emoji = "📚",
                    badgeColor = BrandBlue
                )
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp)
                ) {
                    items(SubjectId.entries) { subject ->
                        val subjectTopics = LkgCurriculumRepository.topicsForSubject(subject)
                        val doneCount = subjectTopics.count { it.id in completedTopicIds }
                        SubjectPlayCard(
                            subject = subject,
                            doneCount = doneCount,
                            totalCount = subjectTopics.size,
                            onClick = { onSubjectSelected(subject) }
                        )
                    }
                }
            }

            // 4. FUN ACTIVITIES
            item {
                SectionPillHeader(
                    title = "Fun Activities",
                    emoji = "🎮",
                    badgeColor = BrandIndigo
                )
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp)
                ) {
                    items(FunActivityKind.entries) { activity ->
                        Tactile3DCard(
                            containerColor = activity.bgColor,
                            lipColor = activity.lipColor,
                            cornerRadius = 22.dp,
                            modifier = Modifier
                                .width(126.dp)
                                .testTag("fun_activity_${activity.name.lowercase()}"),
                            onClick = { onFunActivitySelected(activity) }
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 14.dp, horizontal = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(text = activity.glyph, fontSize = 36.sp)
                                Text(
                                    text = activity.title,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = InkNavy,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // 5. TODAY'S LEARNING PROGRESS, STREAK & REWARDS
            item {
                ProgressSummaryBanner(
                    profile = profile,
                    todayProgressFraction = todayProgressFraction,
                    onOpenRewards = { onFunActivitySelected(FunActivityKind.REWARD_TIME) }
                )
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun HomeTopHeader(
    profile: ChildProfileEntity,
    onOpenParentSettings: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // App Title & Logo Badge
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = PureWhite,
                shadowElevation = 6.dp,
                border = BorderStroke(2.5.dp, SunnyYellow),
                modifier = Modifier.size(46.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(text = "🎓", fontSize = 24.sp)
                }
            }
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Sub Study",
                        style = MaterialTheme.typography.headlineMedium,
                        color = InkNavy
                    )
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = BrandIndigo,
                        border = BorderStroke(1.5.dp, SunnyYellow)
                    ) {
                        Text(
                            text = "★ LKG ★",
                            style = MaterialTheme.typography.labelSmall,
                            color = SunnyYellow,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = "Learn • Practice • Grow",
                    style = MaterialTheme.typography.labelSmall,
                    color = InkNavy.copy(alpha = 0.78f)
                )
            }
        }

        // Child Profile & Parent Gear
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                color = PureWhite.copy(alpha = 0.94f),
                border = BorderStroke(2.dp, SunnyYellow),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = profile.avatarEmoji, fontSize = 18.sp)
                    Column {
                        Text(
                            text = profile.childName,
                            style = MaterialTheme.typography.labelSmall,
                            color = InkNavy,
                            maxLines = 1
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Star,
                                contentDescription = "Stars",
                                tint = AmberGold,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = " ${profile.totalStars}",
                                style = MaterialTheme.typography.labelSmall,
                                color = AmberGold
                            )
                        }
                    }
                }
            }

            Surface(
                shape = CircleShape,
                color = PureWhite.copy(alpha = 0.94f),
                shadowElevation = 4.dp,
                border = BorderStroke(2.dp, BrandBlue.copy(alpha = 0.25f))
            ) {
                IconButton(
                    onClick = onOpenParentSettings,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("parent_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Settings,
                        contentDescription = "Parent Settings",
                        tint = BrandBlue
                    )
                }
            }
        }
    }
}

@Composable
private fun TeacherHeroStage(
    childName: String,
    recommendedTopic: TopicUnit,
    isSpeaking: Boolean,
    teacherCaption: String,
    autoplayCountdown: Int?,
    isAutoplayPaused: Boolean,
    isSessionLimitReached: Boolean,
    isWide: Boolean,
    onContinueLearning: () -> Unit,
    onToggleAutoplayPause: () -> Unit,
    onTapTeacher: () -> Unit
) {
    val pulseTransition = rememberInfiniteTransition(label = "btn_pulse")
    val ctaScale by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.035f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cta_scale"
    )

    Tactile3DCard(
        containerColor = PureWhite,
        lipColor = Color(0xFF93C5FD),
        cornerRadius = 28.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFFE0F2FE), PureWhite)
                    )
                )
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Welcome Greeting Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = SunnyYellow.copy(alpha = 0.35f),
                    border = BorderStroke(1.5.dp, AmberGold)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = null,
                            tint = WarmOrange,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Hello $childName! Aaj hum seekhenge!",
                            style = MaterialTheme.typography.labelLarge,
                            color = InkNavy
                        )
                    }
                }

                IconButton(
                    onClick = onTapTeacher,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VolumeUp,
                        contentDescription = "Repeat Teacher Voice",
                        tint = BrandBlue
                    )
                }
            }

            // Classroom Teacher + Chalkboard Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable(onClick = onTapTeacher)
                ) {
                    AnimatedTeacherAvatar(
                        isSpeaking = isSpeaking,
                        size = if (isWide) 136.dp else 112.dp
                    )
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFFEF3C7),
                        border = BorderStroke(1.dp, AmberGold)
                    ) {
                        Text(
                            text = "Sit Back! Main padhaungi ❤️",
                            style = MaterialTheme.typography.labelSmall,
                            color = InkNavy,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                // Chalkboard Lesson Preview
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .border(4.dp, ChalkboardFrame, RoundedCornerShape(20.dp)),
                    color = ChalkboardGreen
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(text = recommendedTopic.badgeGlyph, fontSize = 30.sp)
                            Column {
                                Text(
                                    text = recommendedTopic.subjectId.title.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SunnyYellow
                                )
                                Text(
                                    text = recommendedTopic.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = PureWhite,
                                    maxLines = 2
                                )
                            }
                        }
                        Text(
                            text = teacherCaption,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFE2E8F0),
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Autoplay Countdown Banner (when Zero-Touch mode is active)
            AnimatedVisibility(visible = autoplayCountdown != null && !isSessionLimitReached) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = EvsGreen.copy(alpha = 0.14f),
                    border = BorderStroke(1.5.dp, EvsGreen)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Auto-starting ${recommendedTopic.subjectId.title} in ${autoplayCountdown ?: 0}s...",
                            style = MaterialTheme.typography.labelLarge,
                            color = FreshGreen
                        )
                        Text(
                            text = "Zero-Touch ✨",
                            style = MaterialTheme.typography.labelSmall,
                            color = FreshGreen
                        )
                    }
                }
            }

            if (isSessionLimitReached) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = WarmOrange.copy(alpha = 0.14f),
                    border = BorderStroke(1.5.dp, WarmOrange)
                ) {
                    Text(
                        text = "Aaram ka Samay! Today's learning limit reached — Parents can extend time in Settings.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkNavy,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Continue Learning CTA + Autoplay Pause/Resume
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onContinueLearning,
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = FreshGreen),
                    contentPadding = PaddingValues(vertical = 14.dp, horizontal = 18.dp),
                    modifier = Modifier
                        .weight(1f)
                        .scale(ctaScale)
                        .minimumInteractiveComponentSize()
                        .testTag("continue_learning_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Continue Learning (Autoplay)",
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Surface(
                    shape = CircleShape,
                    color = if (isAutoplayPaused) WarmOrange else BrandBlue,
                    shadowElevation = 4.dp
                ) {
                    IconButton(
                        onClick = onToggleAutoplayPause,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("autoplay_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isAutoplayPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                            contentDescription = if (isAutoplayPaused) "Resume Autoplay" else "Pause Autoplay",
                            tint = PureWhite
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SubjectPlayCard(
    subject: SubjectId,
    doneCount: Int,
    totalCount: Int,
    onClick: () -> Unit
) {
    Tactile3DCard(
        containerColor = subject.primaryColor,
        lipColor = subject.primaryColor.copy(alpha = 0.72f),
        cornerRadius = 24.dp,
        modifier = Modifier
            .width(138.dp)
            .testTag("subject_card_${subject.name.lowercase()}"),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = subject.title,
                style = MaterialTheme.typography.titleMedium,
                color = PureWhite,
                maxLines = 1
            )
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = PureWhite.copy(alpha = 0.25f),
                modifier = Modifier.size(64.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = subject.shortBadge,
                        style = MaterialTheme.typography.headlineMedium,
                        color = PureWhite
                    )
                }
            }
            Surface(
                shape = RoundedCornerShape(50),
                color = PureWhite.copy(alpha = 0.92f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = FreshGreen,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (doneCount > 0) "$doneCount/$totalCount Done" else "Auto Play",
                        style = MaterialTheme.typography.labelSmall,
                        color = InkNavy
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionPillHeader(
    title: String,
    emoji: String,
    badgeColor: Color
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = badgeColor,
        shadowElevation = 4.dp,
        border = BorderStroke(2.dp, PureWhite)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = emoji, fontSize = 18.sp)
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = PureWhite
            )
        }
    }
}

@Composable
private fun ProgressSummaryBanner(
    profile: ChildProfileEntity,
    todayProgressFraction: Float,
    onOpenRewards: () -> Unit
) {
    val percent = (todayProgressFraction * 100).toInt()
    val nextBadge = LkgCurriculumRepository.rewardBadges.firstOrNull { it.requiredStars > profile.totalStars }
        ?: LkgCurriculumRepository.rewardBadges.last()

    Tactile3DCard(
        containerColor = BrandIndigo,
        lipColor = Color(0xFF312E81),
        cornerRadius = 26.dp,
        modifier = Modifier.fillMaxWidth(),
        onClick = onOpenRewards
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = SunnyYellow,
                modifier = Modifier.size(62.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.EmojiEvents,
                        contentDescription = "Rewards Trophy",
                        tint = Color(0xFF92400E),
                        modifier = Modifier.size(34.dp)
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Today's Learning: $percent%",
                        style = MaterialTheme.typography.titleMedium,
                        color = PureWhite
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.LocalFireDepartment,
                            contentDescription = "Streak",
                            tint = SunnyYellow,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "${profile.streakDays}d Streak",
                            style = MaterialTheme.typography.labelSmall,
                            color = SunnyYellow
                        )
                    }
                }

                LinearProgressIndicator(
                    progress = { todayProgressFraction.coerceAtLeast(0.08f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(50)),
                    color = Color(0xFF4ADE80),
                    trackColor = PureWhite.copy(alpha = 0.25f)
                )

                Text(
                    text = "Next Reward: ${nextBadge.glyph} ${nextBadge.title} (${profile.totalStars}/${nextBadge.requiredStars} ⭐)",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFE0E7FF)
                )
            }
        }
    }
}
