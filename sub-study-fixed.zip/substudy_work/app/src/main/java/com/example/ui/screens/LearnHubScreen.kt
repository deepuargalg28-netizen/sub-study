package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TopicProgressEntity
import com.example.data.model.LkgCurriculumRepository
import com.example.data.model.SubjectId
import com.example.ui.components.Tactile3DCard
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.InkNavy
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted

@Composable
fun LearnHubScreen(
    selectedSubject: SubjectId?,
    topicProgressList: List<TopicProgressEntity>,
    onSelectSubjectFilter: (SubjectId?) -> Unit,
    onStartTopic: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val progressMap = topicProgressList.associateBy { it.topicId }
    val filteredTopics = if (selectedSubject == null) {
        LkgCurriculumRepository.allTopics
    } else {
        LkgCurriculumRepository.topicsForSubject(selectedSubject)
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 900.dp)
                .align(Alignment.TopCenter),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "LKG Classroom Lessons",
                        style = MaterialTheme.typography.headlineLarge,
                        color = InkNavy
                    )
                    Text(
                        text = "Tap any topic — Miss Tara will guide you step-by-step!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SlateMuted
                    )
                }
            }

            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedSubject == null,
                            onClick = { onSelectSubjectFilter(null) },
                            label = { Text("All Subjects") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BrandBlue,
                                selectedLabelColor = PureWhite,
                                containerColor = PureWhite
                            ),
                            modifier = Modifier.minimumInteractiveComponentSize()
                        )
                    }
                    items(SubjectId.entries) { subj ->
                        FilterChip(
                            selected = selectedSubject == subj,
                            onClick = { onSelectSubjectFilter(subj) },
                            label = { Text("${subj.shortBadge} ${subj.title}") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = subj.primaryColor,
                                selectedLabelColor = PureWhite,
                                containerColor = PureWhite
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("learn_filter_${subj.name.lowercase()}")
                        )
                    }
                }
            }

            if (filteredTopics.isNotEmpty()) {
                item {
                    Button(
                        onClick = { onStartTopic(filteredTopics.first().id) },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = FreshGreen),
                        contentPadding = PaddingValues(vertical = 14.dp, horizontal = 20.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("autoplay_filtered_topics_button")
                    ) {
                        Icon(imageVector = Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Auto-Play ${selectedSubject?.title ?: "LKG"} Lessons",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }

            items(filteredTopics, key = { it.id }) { topic ->
                val prog = progressMap[topic.id]
                val completed = (prog?.completionsCount ?: 0) > 0
                Tactile3DCard(
                    containerColor = PureWhite,
                    lipColor = topic.subjectId.primaryColor.copy(alpha = 0.65f),
                    cornerRadius = 24.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("topic_card_${topic.id}"),
                    onClick = { onStartTopic(topic.id) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = topic.subjectId.softColor,
                            border = BorderStroke(2.dp, topic.subjectId.primaryColor.copy(alpha = 0.4f)),
                            modifier = Modifier.size(68.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(text = topic.badgeGlyph, fontSize = 34.sp)
                            }
                        }

                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = topic.subjectId.primaryColor
                            ) {
                                Text(
                                    text = topic.subjectId.title,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = PureWhite,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = topic.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = InkNavy
                            )
                            Text(
                                text = topic.hindiTitle,
                                style = MaterialTheme.typography.bodyMedium,
                                color = SlateMuted
                            )
                        }

                        Column(
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (completed) {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = "Completed",
                                    tint = FreshGreen,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            if ((prog?.starsEarned ?: 0) > 0) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Rounded.Star,
                                        contentDescription = "Stars",
                                        tint = AmberGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "${prog?.starsEarned}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AmberGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Surface(
                                shape = CircleShape,
                                color = topic.subjectId.primaryColor,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Rounded.PlayArrow,
                                        contentDescription = "Start ${topic.title}",
                                        tint = PureWhite
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}
