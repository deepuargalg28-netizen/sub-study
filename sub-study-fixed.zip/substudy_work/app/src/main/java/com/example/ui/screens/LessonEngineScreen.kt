package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.LkgCurriculumRepository
import com.example.ui.components.AnimatedTeacherAvatar
import com.example.ui.components.ConfettiBurstOverlay
import com.example.ui.components.DrawingStudioCanvas
import com.example.ui.components.LessonIllustrationStage
import com.example.ui.components.Tactile3DCard
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.ChalkboardFrame
import com.example.ui.theme.ChalkboardGreen
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.InkNavy
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SunnyYellow
import com.example.ui.theme.WarmOrange
import com.example.viewmodel.LessonStepPhase
import com.example.viewmodel.LessonUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LessonEngineScreen(
    state: LessonUiState,
    isSpeaking: Boolean,
    isListening: Boolean,
    teacherCaption: String,
    exitProtectionEnabled: Boolean,
    onRequestExitWithParentGate: () -> Unit,
    onExitLessonDirect: () -> Unit,
    onTogglePause: () -> Unit,
    onRepeatVoice: () -> Unit,
    onPulseInteractive: () -> Unit,
    onSkipNextItem: () -> Unit,
    onSelectOption: (String) -> Unit,
    onStartVoiceAnswer: () -> Unit,
    onDoneDrawing: () -> Unit,
    onStartNextTopicNow: () -> Unit,
    onUnlockBreakRequest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var micPermissionHint by remember { mutableStateOf<String?>(null) }

    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            micPermissionHint = null
            onStartVoiceAnswer()
        } else {
            micPermissionHint = "Mic permission denied — tap a big picture below to answer!"
        }
    }

    val handleExitClick: () -> Unit = {
        if (exitProtectionEnabled) {
            onRequestExitWithParentGate()
        } else {
            onExitLessonDirect()
        }
    }

    BackHandler {
        handleExitClick()
    }

    DisposableEffect(Unit) {
        onDispose { }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 880.dp)
                .align(Alignment.TopCenter)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Top Lesson Control Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = CircleShape,
                    color = PureWhite,
                    shadowElevation = 4.dp
                ) {
                    IconButton(
                        onClick = handleExitClick,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("lesson_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Exit Lesson",
                            tint = InkNavy
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = state.topic.subjectId.primaryColor,
                    border = BorderStroke(2.dp, PureWhite),
                    shadowElevation = 4.dp
                ) {
                    Text(
                        text = "${state.topic.badgeGlyph} ${state.topic.title}",
                        style = MaterialTheme.typography.titleMedium,
                        color = PureWhite,
                        maxLines = 1,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = PureWhite,
                        border = BorderStroke(2.dp, SunnyYellow)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Star,
                                contentDescription = "Lesson Stars",
                                tint = AmberGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = " ${state.starsEarnedThisLesson}",
                                style = MaterialTheme.typography.titleMedium,
                                color = InkNavy
                            )
                        }
                    }

                    Surface(
                        shape = CircleShape,
                        color = if (state.isPaused) WarmOrange else BrandBlue,
                        shadowElevation = 4.dp
                    ) {
                        IconButton(
                            onClick = onTogglePause,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("lesson_pause_button")
                        ) {
                            Icon(
                                imageVector = if (state.isPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                                contentDescription = if (state.isPaused) "Resume Lesson" else "Pause Lesson",
                                tint = PureWhite
                            )
                        }
                    }
                }
            }

            // Animated Teacher Speech Header
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = PureWhite,
                border = BorderStroke(2.dp, BrandBlue.copy(alpha = 0.25f)),
                shadowElevation = 6.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AnimatedTeacherAvatar(
                        isSpeaking = isSpeaking,
                        isCelebrating = state.phase == LessonStepPhase.CELEBRATE_CORRECT ||
                            state.phase == LessonStepPhase.TOPIC_COMPLETE,
                        size = 86.dp
                    )
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = if (state.isPaused) "Lesson Paused" else "Miss Tara Says:",
                            style = MaterialTheme.typography.labelSmall,
                            color = BrandBlue
                        )
                        Text(
                            text = teacherCaption,
                            style = MaterialTheme.typography.bodyLarge,
                            color = InkNavy
                        )
                    }
                    IconButton(
                        onClick = onRepeatVoice,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.VolumeUp,
                            contentDescription = "Hear Again",
                            tint = BrandBlue
                        )
                    }
                }
            }

            // Main Interactive 10-Step Lesson Stage
            AnimatedContent(
                targetState = state.phase,
                label = "lesson_phase_stage"
            ) { phase ->
                when (phase) {
                    LessonStepPhase.TEACHER_INTRO -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(28.dp),
                            color = ChalkboardGreen,
                            border = BorderStroke(5.dp, ChalkboardFrame),
                            shadowElevation = 8.dp
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(text = state.topic.badgeGlyph, fontSize = 72.sp)
                                Text(
                                    text = state.topic.title,
                                    style = MaterialTheme.typography.headlineLarge,
                                    color = PureWhite,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = state.topic.hindiTitle,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = SunnyYellow,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = "Listen carefully... Lesson starting automatically!",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                        }
                    }

                    LessonStepPhase.COLORFUL_EXPLAIN,
                    LessonStepPhase.INTERACTIVE_EXAMPLE -> {
                        val item = state.topic.items.getOrNull(state.currentItemIndex)
                        if (item != null) {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                LessonIllustrationStage(
                                    item = item,
                                    pulseCount = state.examplePulseCount
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = onPulseInteractive,
                                        shape = RoundedCornerShape(50),
                                        colors = ButtonDefaults.buttonColors(containerColor = item.accentColor),
                                        modifier = Modifier
                                            .weight(1f)
                                            .minimumInteractiveComponentSize()
                                            .testTag("repeat_example_button")
                                    ) {
                                        Icon(Icons.Rounded.VolumeUp, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Say Again!", style = MaterialTheme.typography.titleMedium)
                                    }
                                    OutlinedButton(
                                        onClick = onSkipNextItem,
                                        shape = RoundedCornerShape(50),
                                        modifier = Modifier
                                            .minimumInteractiveComponentSize()
                                            .testTag("next_example_button")
                                    ) {
                                        Text("Next")
                                        Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null)
                                    }
                                }
                            }
                        }
                    }

                    LessonStepPhase.VOICE_QUESTION,
                    LessonStepPhase.GENTLE_RETRY -> {
                        val question = state.topic.questions.getOrNull(state.currentQuestionIndex)
                        if (question != null) {
                            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(24.dp),
                                    color = PureWhite,
                                    border = BorderStroke(
                                        2.5.dp,
                                        if (phase == LessonStepPhase.GENTLE_RETRY) WarmOrange else BrandIndigo
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = if (phase == LessonStepPhase.GENTLE_RETRY) {
                                                "Koi baat nahi! Try once more ❤️"
                                            } else {
                                                "Your Turn! Tap or Speak"
                                            },
                                            style = MaterialTheme.typography.labelLarge,
                                            color = if (phase == LessonStepPhase.GENTLE_RETRY) WarmOrange else BrandIndigo
                                        )
                                        Text(
                                            text = question.promptText,
                                            style = MaterialTheme.typography.headlineMedium,
                                            color = InkNavy,
                                            textAlign = TextAlign.Center
                                        )

                                        // Voice Answer Mic Button
                                        val micTransition = rememberInfiniteTransition(label = "mic")
                                        val micScale by micTransition.animateFloat(
                                            initialValue = 1f,
                                            targetValue = if (isListening) 1.12f else 1.03f,
                                            animationSpec = infiniteRepeatable(
                                                animation = tween(550, easing = FastOutSlowInEasing),
                                                repeatMode = RepeatMode.Reverse
                                            ),
                                            label = "mic_scale"
                                        )
                                        Button(
                                            onClick = {
                                                val granted = ContextCompat.checkSelfPermission(
                                                    context,
                                                    Manifest.permission.RECORD_AUDIO
                                                ) == PackageManager.PERMISSION_GRANTED
                                                if (granted) {
                                                    onStartVoiceAnswer()
                                                } else {
                                                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                                }
                                            },
                                            shape = RoundedCornerShape(50),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (isListening) WarmOrange else BrandBlue
                                            ),
                                            modifier = Modifier
                                                .scale(micScale)
                                                .minimumInteractiveComponentSize()
                                                .testTag("speak_answer_button")
                                        ) {
                                            Icon(Icons.Rounded.Mic, contentDescription = "Speak Answer")
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = if (isListening) "Sun rahi hoon... Bolo!" else "Bolo / Speak 🎤",
                                                style = MaterialTheme.typography.titleMedium
                                            )
                                        }

                                        (micPermissionHint ?: state.micFeedback)?.let { hint ->
                                            Text(
                                                text = hint,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = WarmOrange,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }

                                // Large Kid-Friendly Answer Option Cards
                                FlowRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp),
                                    maxItemsInEachRow = 3
                                ) {
                                    question.options.forEach { option ->
                                        val isWrongPicked = state.selectedWrongOptionId == option.id
                                        Tactile3DCard(
                                            containerColor = if (isWrongPicked) Color(0xFFFFEDD5) else PureWhite,
                                            lipColor = if (isWrongPicked) WarmOrange else option.accentColor,
                                            cornerRadius = 24.dp,
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("quiz_option_${option.id}"),
                                            onClick = { onSelectOption(option.id) }
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 18.dp, horizontal = 10.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(text = option.glyph, fontSize = 50.sp)
                                                Text(
                                                    text = option.label,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    color = InkNavy,
                                                    textAlign = TextAlign.Center
                                                )
                                                Text(
                                                    text = option.subLabel,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = SlateMuted,
                                                    textAlign = TextAlign.Center
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    LessonStepPhase.CELEBRATE_CORRECT -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(28.dp),
                            color = Color(0xFFDCFCE7),
                            border = BorderStroke(3.dp, FreshGreen),
                            shadowElevation = 8.dp
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(text = "🌟🎉🌟", fontSize = 54.sp)
                                Text(
                                    text = "Shabaash Little Star!",
                                    style = MaterialTheme.typography.headlineLarge,
                                    color = FreshGreen,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = "+2 Gold Stars Earned!",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = InkNavy
                                )
                            }
                        }
                    }

                    LessonStepPhase.DRAWING_STUDIO -> {
                        DrawingStudioCanvas(
                            mode = state.topic.drawingMode,
                            tracingTargets = state.topic.tracingTargets,
                            onStrokeStarted = {},
                            onDoneDrawing = onDoneDrawing
                        )
                    }

                    LessonStepPhase.SHORT_REVISION -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(28.dp),
                            color = PureWhite,
                            border = BorderStroke(3.dp, SunnyYellow),
                            shadowElevation = 6.dp
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(18.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "Quick Revision! 📝",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = BrandIndigo
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    state.topic.items.forEach { item ->
                                        Surface(
                                            shape = RoundedCornerShape(18.dp),
                                            color = item.accentColor.copy(alpha = 0.14f),
                                            border = BorderStroke(1.5.dp, item.accentColor)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text(text = item.subGlyph, fontSize = 24.sp)
                                                Text(
                                                    text = item.title,
                                                    style = MaterialTheme.typography.labelLarge,
                                                    color = InkNavy
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    LessonStepPhase.TOPIC_COMPLETE -> {
                        val nextTopic = LkgCurriculumRepository.nextTopicAfter(state.topic.id)
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(28.dp),
                            color = PureWhite,
                            border = BorderStroke(3.dp, FreshGreen),
                            shadowElevation = 8.dp
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(text = "🏆", fontSize = 68.sp)
                                Text(
                                    text = "Topic Complete!",
                                    style = MaterialTheme.typography.headlineLarge,
                                    color = FreshGreen
                                )
                                Text(
                                    text = "You earned ${state.starsEarnedThisLesson} Stars ⭐",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = AmberGold
                                )
                                Text(
                                    text = "Next up: ${nextTopic.badgeGlyph} ${nextTopic.title} in ${state.autoAdvanceCountdown}s...",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = BrandBlue,
                                    textAlign = TextAlign.Center
                                )
                                Button(
                                    onClick = onStartNextTopicNow,
                                    shape = RoundedCornerShape(50),
                                    colors = ButtonDefaults.buttonColors(containerColor = FreshGreen),
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Text("Start Next Topic Now ▶", style = MaterialTheme.typography.titleMedium)
                                }
                            }
                        }
                    }

                    LessonStepPhase.SAFE_BREAK -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(28.dp),
                            color = Color(0xFFFFFBEB),
                            border = BorderStroke(3.dp, AmberGold),
                            shadowElevation = 8.dp
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(26.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(text = "🌙✨", fontSize = 64.sp)
                                Text(
                                    text = "Aaram ka Samay! (Safe Break)",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = InkNavy,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = "Bahut achha padha aaj! Now rest your eyes, drink water, and play outside!",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = SlateMuted,
                                    textAlign = TextAlign.Center
                                )
                                OutlinedButton(
                                    onClick = onUnlockBreakRequest,
                                    shape = RoundedCornerShape(50),
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Rounded.LockOpen, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Parents: Unlock More Time")
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Celebration Confetti Particles
        ConfettiBurstOverlay(
            visible = state.phase == LessonStepPhase.CELEBRATE_CORRECT ||
                state.phase == LessonStepPhase.TOPIC_COMPLETE
        )
    }
}
