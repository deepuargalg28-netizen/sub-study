package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChildProfileEntity
import com.example.data.local.ParentSettings
import com.example.data.local.TopicProgressEntity
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.InkNavy
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.WarmOrange

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ParentSettingsScreen(
    profile: ChildProfileEntity,
    settings: ParentSettings,
    topicProgressList: List<TopicProgressEntity>,
    onBack: () -> Unit,
    onUpdateProfile: (String, String, Int) -> Unit,
    onSetSessionLimitMinutes: (Int) -> Unit,
    onResetTodayTimer: () -> Unit,
    onSetAutoplayEnabled: (Boolean) -> Unit,
    onSetVoiceTeacherEnabled: (Boolean) -> Unit,
    onSetSoundEffectsEnabled: (Boolean) -> Unit,
    onSetSpeechRate: (Float) -> Unit,
    onSetExitProtectionEnabled: (Boolean) -> Unit,
    onUpdatePin: (String) -> Unit,
    onResetProgress: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    var childName by remember(profile.childName) { mutableStateOf(profile.childName) }
    var selectedAvatar by remember(profile.avatarEmoji) { mutableStateOf(profile.avatarEmoji) }
    var dailyGoal by remember(profile.dailyGoalActivities) { mutableIntStateOf(profile.dailyGoalActivities) }
    var newPin by remember { mutableStateOf("") }
    var savedBanner by remember { mutableStateOf<String?>(null) }

    val avatars = listOf("🌟", "🦁", "🦋", "🐼", "🚀", "🦄")
    val timeLimits = listOf(10, 15, 20, 30, 0) // 0 = Unlimited

    val totalCorrect = topicProgressList.sumOf { it.questionsCorrect }
    val totalAttempted = topicProgressList.sumOf { it.questionsAttempted }
    val accuracy = if (totalAttempted > 0) ((totalCorrect * 100) / totalAttempted) else 100
    val minutesUsedToday = settings.todayElapsedSeconds / 60

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 860.dp)
                .align(Alignment.TopCenter),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(shape = CircleShape, color = PureWhite, shadowElevation = 4.dp) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("parent_settings_back")
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back to App")
                        }
                    }
                    Column {
                        Text(
                            text = "Parent Controls & Reports",
                            style = MaterialTheme.typography.headlineMedium,
                            color = InkNavy
                        )
                        Text(
                            text = "Safe settings locked away from children",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SlateMuted
                        )
                    }
                }
            }

            savedBanner?.let { msg ->
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = FreshGreen.copy(alpha = 0.14f),
                        border = BorderStroke(1.5.dp, FreshGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.labelLarge,
                            color = FreshGreen,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            // 1. Child Profile Section
            item {
                SettingsCard(title = "Child Profile (LKG)") {
                    OutlinedTextField(
                        value = childName,
                        onValueChange = { childName = it },
                        label = { Text("Child Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Choose Avatar", style = MaterialTheme.typography.labelLarge, color = InkNavy)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        avatars.forEach { emoji ->
                            Surface(
                                shape = CircleShape,
                                color = if (emoji == selectedAvatar) BrandBlue.copy(alpha = 0.18f) else PureWhite,
                                border = BorderStroke(
                                    2.dp,
                                    if (emoji == selectedAvatar) BrandBlue else SlateMuted.copy(alpha = 0.3f)
                                ),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .clickable { selectedAvatar = emoji }
                            ) {
                                Box(
                                    modifier = Modifier.padding(10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = emoji, fontSize = 24.sp)
                                }
                            }
                        }
                    }
                    Text("Daily Activities Goal: $dailyGoal", style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = dailyGoal.toFloat(),
                        onValueChange = { dailyGoal = it.toInt() },
                        valueRange = 3f..12f,
                        steps = 8
                    )
                    Button(
                        onClick = {
                            onUpdateProfile(childName, selectedAvatar, dailyGoal)
                            savedBanner = "Child profile saved!"
                        },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Text("Save Child Profile")
                    }
                }
            }

            // 2. Session Time Limit & Safety
            item {
                SettingsCard(title = "Screen Time & Exit Protection") {
                    Text(
                        text = "Used Today: $minutesUsedToday min • Limit: ${if (settings.sessionLimitMinutes == 0) "Unlimited" else "${settings.sessionLimitMinutes} min"}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BrandBlue
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        timeLimits.forEach { mins ->
                            FilterChip(
                                selected = settings.sessionLimitMinutes == mins,
                                onClick = { onSetSessionLimitMinutes(mins) },
                                label = { Text(if (mins == 0) "Unlimited" else "${mins}m") },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            onResetTodayTimer()
                            savedBanner = "Today's screen-time timer reset."
                        },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Text("Reset Today's Timer")
                    }

                    SettingsToggleRow(
                        label = "Exit Protection (Child Lock)",
                        subtitle = "Require parent check before leaving lessons or exiting app",
                        checked = settings.exitProtectionEnabled,
                        onCheckedChange = onSetExitProtectionEnabled,
                        testTag = "toggle_exit_protection"
                    )
                }
            }

            // 3. Sound, Voice Teacher & Autoplay
            item {
                SettingsCard(title = "Voice Teacher & Autoplay") {
                    SettingsToggleRow(
                        label = "Zero-Touch Autoplay",
                        subtitle = "Automatically greet & start lessons without menus",
                        checked = settings.autoplayEnabled,
                        onCheckedChange = onSetAutoplayEnabled,
                        testTag = "toggle_autoplay"
                    )
                    SettingsToggleRow(
                        label = "Voice Teacher (Hindi-English)",
                        subtitle = "Spoken instructions and gentle encouragement",
                        checked = settings.voiceTeacherEnabled,
                        onCheckedChange = onSetVoiceTeacherEnabled,
                        testTag = "toggle_voice"
                    )
                    SettingsToggleRow(
                        label = "Sound Effects & Rhymes",
                        subtitle = "Musical chimes, celebrations & nursery rhymes",
                        checked = settings.soundEffectsEnabled,
                        onCheckedChange = onSetSoundEffectsEnabled,
                        testTag = "toggle_sfx"
                    )
                    Text(
                        text = "Teacher Speaking Speed: ${"%.2f".format(settings.speechRate)}x",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Slider(
                        value = settings.speechRate,
                        onValueChange = onSetSpeechRate,
                        valueRange = 0.70f..1.20f
                    )
                }
            }

            // 4. Progress Report & Security PIN
            item {
                SettingsCard(title = "Parent Report & Security") {
                    Text(
                        text = "Topics Attempted: ${topicProgressList.size} • Quiz Accuracy: $accuracy% • Total Stars: ${profile.totalStars}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = InkNavy
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newPin,
                            onValueChange = { if (it.length <= 4) newPin = it.filter(Char::isDigit) },
                            label = { Text("New 4-Digit PIN") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                if (newPin.length == 4) {
                                    onUpdatePin(newPin)
                                    newPin = ""
                                    savedBanner = "Parent PIN updated!"
                                }
                            },
                            enabled = newPin.length == 4,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Text("Set PIN")
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            onResetProgress()
                            savedBanner = "Progress reset to fresh start."
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = WarmOrange),
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Text("Reset Child Progress")
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun SettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = PureWhite,
        border = BorderStroke(1.5.dp, BrandBlue.copy(alpha = 0.2f)),
        shadowElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = BrandBlue
            )
            content()
        }
    }
}

@Composable
private fun SettingsToggleRow(
    label: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(text = label, style = MaterialTheme.typography.titleMedium, color = InkNavy)
            Text(text = subtitle, style = MaterialTheme.typography.bodyMedium, color = SlateMuted)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
    }
}
