package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChildProfileEntity
import com.example.data.local.SessionLogEntity
import com.example.data.local.TopicProgressEntity
import com.example.data.model.LkgCurriculumRepository
import com.example.data.model.SubjectId
import com.example.ui.components.Tactile3DCard
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.InkNavy
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SunnyYellow
import com.example.ui.theme.WarmOrange

@Composable
fun ProgressScreen(
    profile: ChildProfileEntity,
    topicProgressList: List<TopicProgressEntity>,
    recentSessions: List<SessionLogEntity>,
    todayProgressFraction: Float,
    onOpenParentControls: () -> Unit,
    modifier: Modifier = Modifier
) {
    val completedTopicIds = topicProgressList.filter { it.completionsCount > 0 }.map { it.topicId }.toSet()

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 900.dp)
                .align(Alignment.TopCenter),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "${profile.childName}'s Progress",
                    style = MaterialTheme.typography.headlineLarge,
                    color = InkNavy
                )
            }

            // Stats Row: Stars, Streak, Today Goal
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatTactileTile(
                        title = "Total Stars",
                        value = "${profile.totalStars} ⭐",
                        color = AmberGold,
                        modifier = Modifier.weight(1f)
                    )
                    StatTactileTile(
                        title = "Streak",
                        value = "${profile.streakDays} Days 🔥",
                        color = WarmOrange,
                        modifier = Modifier.weight(1f)
                    )
                    StatTactileTile(
                        title = "Today",
                        value = "${(todayProgressFraction * 100).toInt()}%",
                        color = FreshGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Subject Mastery Breakdown
            item {
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = PureWhite,
                    border = BorderStroke(2.dp, BrandBlue.copy(alpha = 0.25f)),
                    shadowElevation = 6.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Subject Mastery (LKG)",
                            style = MaterialTheme.typography.titleLarge,
                            color = InkNavy
                        )

                        SubjectId.entries.forEach { subj ->
                            val topics = LkgCurriculumRepository.topicsForSubject(subj)
                            val done = topics.count { it.id in completedTopicIds }
                            val ratio = if (topics.isEmpty()) 0f else done.toFloat() / topics.size.toFloat()
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${subj.shortBadge} ${subj.title} (${subj.hindiLabel})",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = InkNavy
                                    )
                                    Text(
                                        text = "$done / ${topics.size}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = subj.primaryColor
                                    )
                                }
                                LinearProgressIndicator(
                                    progress = { ratio.coerceAtLeast(0.05f) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(50)),
                                    color = subj.primaryColor,
                                    trackColor = subj.softColor
                                )
                            }
                        }
                    }
                }
            }

            // Parent Report & Settings Entry
            item {
                Button(
                    onClick = onOpenParentControls,
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("progress_open_parent_button")
                ) {
                    Icon(Icons.Rounded.Lock, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Parent Reports & Safety Controls", style = MaterialTheme.typography.titleMedium)
                }
            }

            // Recent Activity Log
            item {
                Text(
                    text = "Recent Learning Activities",
                    style = MaterialTheme.typography.titleLarge,
                    color = InkNavy
                )
            }

            if (recentSessions.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = PureWhite,
                        border = BorderStroke(1.5.dp, SunnyYellow),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = "🌟", fontSize = 36.sp)
                            Text(
                                text = "Complete your first lesson or game to see your stars here!",
                                style = MaterialTheme.typography.bodyLarge,
                                color = SlateMuted
                            )
                        }
                    }
                }
            } else {
                items(recentSessions.take(10), key = { it.id }) { session ->
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = PureWhite,
                        shadowElevation = 3.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = session.topicTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = InkNavy
                                )
                                Text(
                                    text = "${session.subjectId} • ${session.correctAnswers}/${session.totalQuestions} answers",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SlateMuted
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = SunnyYellow.copy(alpha = 0.3f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Star,
                                        contentDescription = null,
                                        tint = AmberGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "+${session.starsEarned}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = InkNavy
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun StatTactileTile(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Tactile3DCard(
        containerColor = PureWhite,
        lipColor = color,
        cornerRadius = 22.dp,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = color
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = SlateMuted
            )
        }
    }
}
