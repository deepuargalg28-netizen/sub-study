package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sky & Meadow Classroom Atmosphere
val SkyTop = Color(0xFF38BDF8)
val SkyBottom = Color(0xFFBAE6FD)
val MeadowLight = Color(0xFF86EFAC)
val MeadowDark = Color(0xFF22C55E)
val SunGold = Color(0xFFFACC15)

// Core Brand & Semantic Tokens
val BrandBlue = Color(0xFF1D4ED8)
val BrandBlueLight = Color(0xFF3B82F6)
val BrandIndigo = Color(0xFF4F46E5)
val SunnyYellow = Color(0xFFFFD54F)
val WarmOrange = Color(0xFFFF7043)
val BerryPink = Color(0xFFEC4899)
val BerryPinkDark = Color(0xFFBE185D)
val FreshGreen = Color(0xFF16A34A)
val FreshGreenBright = Color(0xFF22C55E)
val GrapePurple = Color(0xFF8B5CF6)
val GrapePurpleDark = Color(0xFF6D28D9)
val AmberGold = Color(0xFFF59E0B)
val AmberGoldDark = Color(0xFFD97706)

// Subject Card Palettes (vibrant kid-friendly 3D cartoon cards)
val EnglishPink = Color(0xFFF43F5E)
val EnglishPinkSoft = Color(0xFFFFE4E6)
val MathsBlue = Color(0xFF0EA5E9)
val MathsBlueSoft = Color(0xFFE0F2FE)
val HindiAmber = Color(0xFFF59E0B)
val HindiAmberSoft = Color(0xFFFEF3C7)
val EvsGreen = Color(0xFF22C55E)
val EvsGreenSoft = Color(0xFFDCFCE7)
val DrawingPurple = Color(0xFF8B5CF6)
val DrawingPurpleSoft = Color(0xFFEDE9FE)

// High-Contrast Surfaces & Text
val CreamSurface = Color(0xFFFFFDF7)
val PureWhite = Color(0xFFFFFFFF)
val SoftSlateBg = Color(0xFFF0F9FF)
val InkNavy = Color(0xFF0F172A)
val SlateMuted = Color(0xFF475569)
val ChalkboardGreen = Color(0xFF14532D)
val ChalkboardFrame = Color(0xFFB45309)
val CorrectGreen = Color(0xFF16A34A)
val GentleAmber = Color(0xFFF97316)
