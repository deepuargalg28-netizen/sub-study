package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val SubStudyColorScheme = lightColorScheme(
    primary = BrandBlue,
    onPrimary = PureWhite,
    primaryContainer = MathsBlueSoft,
    onPrimaryContainer = InkNavy,
    secondary = BerryPink,
    onSecondary = PureWhite,
    secondaryContainer = EnglishPinkSoft,
    onSecondaryContainer = InkNavy,
    tertiary = FreshGreen,
    onTertiary = PureWhite,
    tertiaryContainer = EvsGreenSoft,
    onTertiaryContainer = InkNavy,
    background = SoftSlateBg,
    onBackground = InkNavy,
    surface = CreamSurface,
    onSurface = InkNavy,
    surfaceVariant = PureWhite,
    onSurfaceVariant = SlateMuted,
    error = WarmOrange,
    onError = PureWhite
)

val SubStudyShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp)
)

@Composable
fun SubStudyTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SubStudyColorScheme,
        typography = SubStudyTypography,
        shapes = SubStudyShapes,
        content = content
    )
}
