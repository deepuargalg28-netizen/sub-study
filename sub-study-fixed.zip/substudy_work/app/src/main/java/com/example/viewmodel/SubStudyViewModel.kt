package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.VoiceTeacherEngine
import com.example.data.local.ChildProfileEntity
import com.example.data.local.ParentSettings
import com.example.data.local.ParentSettingsDataStore
import com.example.data.local.SessionLogEntity
import com.example.data.local.SubStudyDatabase
import com.example.data.local.SubStudyRepository
import com.example.data.local.TopicProgressEntity
import com.example.data.model.DrawingMode
import com.example.data.model.LkgCurriculumRepository
import com.example.data.model.SubjectId
import com.example.data.model.TopicUnit
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class LessonStepPhase {
    TEACHER_INTRO,        // 1. Animated teacher introduces the topic
    COLORFUL_EXPLAIN,     // 2. Explain using colourful illustrations
    INTERACTIVE_EXAMPLE,  // 3. Play an interactive animated example
    VOICE_QUESTION,       // 4 & 5. Ask a voice-based question + tap/speak answer
    CELEBRATE_CORRECT,    // 6. Celebrate with animations, stars & praise
    GENTLE_RETRY,         // 7. Explain again patiently with another example
    DRAWING_STUDIO,       // Guided drawing, colouring or tracing
    SHORT_REVISION,       // 9. Play short revision
    TOPIC_COMPLETE,       // 10. Auto-begin next topic countdown
    SAFE_BREAK            // 10b. Safe session break when parent limit reached
}

data class LessonUiState(
    val topic: TopicUnit = LkgCurriculumRepository.allTopics.first(),
    val phase: LessonStepPhase = LessonStepPhase.TEACHER_INTRO,
    val currentItemIndex: Int = 0,
    val currentQuestionIndex: Int = 0,
    val starsEarnedThisLesson: Int = 0,
    val correctCount: Int = 0,
    val attemptedCount: Int = 0,
    val isPaused: Boolean = false,
    val autoAdvanceCountdown: Int = 4,
    val examplePulseCount: Int = 0,
    val selectedWrongOptionId: String? = null,
    val lastSpokenAnswer: String? = null,
    val micFeedback: String? = null,
    val tracingCompletedCount: Int = 0,
    val sessionStartTimeMillis: Long = System.currentTimeMillis()
)

class SubStudyViewModel(application: Application) : AndroidViewModel(application) {

    private val database = SubStudyDatabase.getInstance(application)
    private val settingsStore = ParentSettingsDataStore(application)
    private val repository = SubStudyRepository(database.subStudyDao(), settingsStore)
    val voiceEngine = VoiceTeacherEngine(application)

    val profile: StateFlow<ChildProfileEntity> = repository.profileFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        ChildProfileEntity()
    )

    val parentSettings: StateFlow<ParentSettings> = repository.parentSettingsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        ParentSettings()
    )

    val topicProgressList: StateFlow<List<TopicProgressEntity>> = repository.topicProgressFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val recentSessions: StateFlow<List<SessionLogEntity>> = repository.recentSessionsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val isSpeaking: StateFlow<Boolean> = voiceEngine.isSpeaking
    val teacherCaption: StateFlow<String> = voiceEngine.currentCaption
    val isListening: StateFlow<Boolean> = voiceEngine.isListening
    val activeRhymeLineIndex: StateFlow<Int> = voiceEngine.activeRhymeLineIndex

    // Zero-touch Home Autoplay state
    private val _homeAutoplayCountdown = MutableStateFlow<Int?>(null)
    val homeAutoplayCountdown: StateFlow<Int?> = _homeAutoplayCountdown.asStateFlow()

    private val _homeAutoplayPaused = MutableStateFlow(false)
    val homeAutoplayPaused: StateFlow<Boolean> = _homeAutoplayPaused.asStateFlow()

    private val _recommendedTopic = MutableStateFlow(LkgCurriculumRepository.allTopics.first())
    val recommendedTopic: StateFlow<TopicUnit> = _recommendedTopic.asStateFlow()

    private val _lessonState = MutableStateFlow(LessonUiState())
    val lessonState: StateFlow<LessonUiState> = _lessonState.asStateFlow()

    private val _isSessionLimitReached = MutableStateFlow(false)
    val isSessionLimitReached: StateFlow<Boolean> = _isSessionLimitReached.asStateFlow()

    private val _isInParentArea = MutableStateFlow(false)
    private var hasGreetedOnLaunch = false
    private var homeCountdownJob: Job? = null
    private var lessonPhaseJob: Job? = null
    private var sessionTickerJob: Job? = null

    val todayProgressFraction: StateFlow<Float> = combine(profile, topicProgressList) { prof, _ ->
        val goal = prof.dailyGoalActivities.coerceAtLeast(1)
        (prof.todayCompletedActivities.toFloat() / goal.toFloat()).coerceIn(0f, 1f)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0f)

    init {
        viewModelScope.launch {
            repository.ensureInitialized()
        }
        viewModelScope.launch {
            parentSettings.collect { settings ->
                voiceEngine.updateSettings(
                    voiceEnabled = settings.voiceTeacherEnabled,
                    sfxEnabled = settings.soundEffectsEnabled,
                    speechRate = settings.speechRate
                )
                val today = repository.todayDateKey()
                val elapsed = if (settings.lastUsageDateKey == today) settings.todayElapsedSeconds else 0
                val limitSec = settings.sessionLimitMinutes * 60
                _isSessionLimitReached.value = settings.sessionLimitMinutes > 0 && elapsed >= limitSec
            }
        }
        viewModelScope.launch {
            topicProgressList.collect { progress ->
                val completedIds = progress.filter { it.completionsCount > 0 }.map { it.topicId }.toSet()
                val next = LkgCurriculumRepository.allTopics.firstOrNull { it.id !in completedIds }
                    ?: LkgCurriculumRepository.allTopics.first()
                _recommendedTopic.value = next
            }
        }
        startSessionTicker()
    }

    private fun startSessionTicker() {
        sessionTickerJob?.cancel()
        sessionTickerJob = viewModelScope.launch {
            while (isActive) {
                delay(5000L)
                if (!_isInParentArea.value && !_isSessionLimitReached.value) {
                    repository.addElapsedSeconds(5)
                }
            }
        }
    }

    fun setParentAreaActive(active: Boolean) {
        _isInParentArea.value = active
        if (active) {
            pauseHomeAutoplay()
            voiceEngine.stopSpeaking()
            voiceEngine.stopRhyme()
        }
    }

    fun onHomeEntered(onAutoLaunchLesson: (String) -> Unit) {
        if (!hasGreetedOnLaunch) {
            hasGreetedOnLaunch = true
            val childName = profile.value.childName
            val topic = _recommendedTopic.value
            val greeting = "Namaste $childName! Welcome to Sub Study! Aaj hum ${topic.subjectId.title} mein ${topic.title} seekhenge! Sit back, main aapko khud padhaungi!"
            voiceEngine.speak(greeting) {
                if (parentSettings.value.autoplayEnabled && !_homeAutoplayPaused.value && !_isSessionLimitReached.value) {
                    startHomeAutoplayCountdown(onAutoLaunchLesson)
                }
            }
        } else {
            voiceEngine.speak(
                "Hello ${profile.value.childName}! Chalo dekhein aaj hum kya naya seekhein!",
                caption = "Hello ${profile.value.childName}! Aaj hum seekhenge!"
            )
        }
    }

    fun startHomeAutoplayCountdown(onAutoLaunchLesson: (String) -> Unit) {
        if (_isSessionLimitReached.value || _homeAutoplayPaused.value) return
        homeCountdownJob?.cancel()
        homeCountdownJob = viewModelScope.launch {
            for (sec in 5 downTo 1) {
                if (!isActive || _homeAutoplayPaused.value || !parentSettings.value.autoplayEnabled) {
                    _homeAutoplayCountdown.value = null
                    return@launch
                }
                _homeAutoplayCountdown.value = sec
                delay(1000L)
            }
            _homeAutoplayCountdown.value = null
            onAutoLaunchLesson(_recommendedTopic.value.id)
        }
    }

    fun toggleHomeAutoplayPause(onAutoLaunchLesson: (String) -> Unit) {
        val nowPaused = !_homeAutoplayPaused.value
        _homeAutoplayPaused.value = nowPaused
        voiceEngine.playTapPop()
        if (nowPaused) {
            homeCountdownJob?.cancel()
            _homeAutoplayCountdown.value = null
            voiceEngine.stopSpeaking()
        } else {
            startHomeAutoplayCountdown(onAutoLaunchLesson)
        }
    }

    fun pauseHomeAutoplay() {
        homeCountdownJob?.cancel()
        _homeAutoplayCountdown.value = null
    }

    fun speakMessage(text: String) {
        voiceEngine.speak(text)
    }

    fun playTapSound() {
        voiceEngine.playTapPop()
    }

    // ==================== 10-STEP AUTOMATIC LESSON ENGINE ====================

    fun startLesson(topicId: String) {
        pauseHomeAutoplay()
        lessonPhaseJob?.cancel()
        val topic = LkgCurriculumRepository.topicById(topicId)
        if (_isSessionLimitReached.value) {
            _lessonState.value = LessonUiState(
                topic = topic,
                phase = LessonStepPhase.SAFE_BREAK
            )
            voiceEngine.speak("Aaj ki padhai poori hui! Ab thoda khel lo aur aankhon ko aaram do!")
            return
        }

        _lessonState.value = LessonUiState(
            topic = topic,
            phase = LessonStepPhase.TEACHER_INTRO,
            currentItemIndex = 0,
            currentQuestionIndex = 0,
            starsEarnedThisLesson = 0,
            correctCount = 0,
            attemptedCount = 0,
            isPaused = false,
            sessionStartTimeMillis = System.currentTimeMillis()
        )
        runCurrentLessonPhase()
    }

    fun toggleLessonPause() {
        val paused = !_lessonState.value.isPaused
        _lessonState.update { it.copy(isPaused = paused) }
        voiceEngine.playTapPop()
        if (paused) {
            lessonPhaseJob?.cancel()
            voiceEngine.stopSpeaking()
        } else {
            runCurrentLessonPhase()
        }
    }

    fun stopLesson() {
        lessonPhaseJob?.cancel()
        voiceEngine.stopSpeaking()
        voiceEngine.stopListening()
    }

    private fun runCurrentLessonPhase() {
        lessonPhaseJob?.cancel()
        val state = _lessonState.value
        if (state.isPaused) return

        val topic = state.topic
        when (state.phase) {
            LessonStepPhase.TEACHER_INTRO -> {
                voiceEngine.speak(topic.teacherIntroVoice) {
                    if (!_lessonState.value.isPaused) {
                        val nextPhase = if (topic.drawingMode != DrawingMode.NONE && topic.items.size <= 1) {
                            LessonStepPhase.DRAWING_STUDIO
                        } else {
                            LessonStepPhase.COLORFUL_EXPLAIN
                        }
                        _lessonState.update { it.copy(phase = nextPhase, currentItemIndex = 0) }
                        runCurrentLessonPhase()
                    }
                }
            }

            LessonStepPhase.COLORFUL_EXPLAIN -> {
                val item = topic.items.getOrNull(state.currentItemIndex)
                if (item == null) {
                    moveToInteractiveOrQuiz()
                    return
                }
                voiceEngine.speak(
                    text = "${item.teacherIntro} ${item.phonicsText}",
                    caption = "${item.title} — ${item.hindiHint}"
                ) {
                    if (!_lessonState.value.isPaused) {
                        _lessonState.update {
                            it.copy(phase = LessonStepPhase.INTERACTIVE_EXAMPLE, examplePulseCount = 1)
                        }
                        runCurrentLessonPhase()
                    }
                }
            }

            LessonStepPhase.INTERACTIVE_EXAMPLE -> {
                val item = topic.items.getOrNull(state.currentItemIndex)
                if (item == null) {
                    moveToInteractiveOrQuiz()
                    return
                }
                voiceEngine.playStarDing()
                voiceEngine.speak(
                    text = item.teacherExplain,
                    caption = item.teacherExplain
                ) {
                    lessonPhaseJob = viewModelScope.launch {
                        delay(900L)
                        if (_lessonState.value.isPaused) return@launch
                        val nextIdx = state.currentItemIndex + 1
                        if (nextIdx < topic.items.size) {
                            _lessonState.update {
                                it.copy(
                                    phase = LessonStepPhase.COLORFUL_EXPLAIN,
                                    currentItemIndex = nextIdx
                                )
                            }
                            runCurrentLessonPhase()
                        } else {
                            moveToInteractiveOrQuiz()
                        }
                    }
                }
            }

            LessonStepPhase.DRAWING_STUDIO -> {
                val guideText = if (topic.drawingMode == DrawingMode.TRACE_GUIDE) {
                    "Apni finger se dotted lines ke upar pyaar se trace karo! Jab ho jaye toh Done dabao!"
                } else {
                    "Apna favourite colour chuno aur sundar drawing mein rang bharo!"
                }
                voiceEngine.speak(guideText)
            }

            LessonStepPhase.VOICE_QUESTION -> {
                val question = topic.questions.getOrNull(state.currentQuestionIndex)
                if (question == null) {
                    enterRevisionPhase()
                    return
                }
                _lessonState.update { it.copy(selectedWrongOptionId = null, micFeedback = null) }
                voiceEngine.speak(question.promptVoice, caption = question.promptText)
            }

            LessonStepPhase.CELEBRATE_CORRECT -> {
                val question = topic.questions.getOrNull(state.currentQuestionIndex)
                voiceEngine.playCelebrateFanfare()
                val praise = question?.praiseVoice ?: "Shabaash Little Star! Bahut achhe!"
                voiceEngine.speak(praise) {
                    lessonPhaseJob = viewModelScope.launch {
                        delay(1100L)
                        if (_lessonState.value.isPaused) return@launch
                        val nextQ = state.currentQuestionIndex + 1
                        if (nextQ < topic.questions.size) {
                            _lessonState.update {
                                it.copy(
                                    phase = LessonStepPhase.VOICE_QUESTION,
                                    currentQuestionIndex = nextQ
                                )
                            }
                            runCurrentLessonPhase()
                        } else if (topic.drawingMode != DrawingMode.NONE) {
                            _lessonState.update { it.copy(phase = LessonStepPhase.DRAWING_STUDIO) }
                            runCurrentLessonPhase()
                        } else {
                            enterRevisionPhase()
                        }
                    }
                }
            }

            LessonStepPhase.GENTLE_RETRY -> {
                val question = topic.questions.getOrNull(state.currentQuestionIndex)
                voiceEngine.playGentleTryAgain()
                val retryMsg = question?.gentleRetryVoice ?: "Koi baat nahi beta! Chalo phir se try karte hain!"
                voiceEngine.speak(retryMsg) {
                    if (!_lessonState.value.isPaused) {
                        _lessonState.update {
                            it.copy(phase = LessonStepPhase.VOICE_QUESTION)
                        }
                    }
                }
            }

            LessonStepPhase.SHORT_REVISION -> {
                voiceEngine.playStarDing()
                voiceEngine.speak(topic.revisionVoice) {
                    if (!_lessonState.value.isPaused) {
                        completeTopicAndPrepareNext()
                    }
                }
            }

            LessonStepPhase.TOPIC_COMPLETE -> {
                lessonPhaseJob = viewModelScope.launch {
                    for (sec in 4 downTo 1) {
                        if (!isActive || _lessonState.value.isPaused) return@launch
                        _lessonState.update { it.copy(autoAdvanceCountdown = sec) }
                        delay(1000L)
                    }
                    if (!_lessonState.value.isPaused) {
                        val nextTopic = LkgCurriculumRepository.nextTopicAfter(_lessonState.value.topic.id)
                        startLesson(nextTopic.id)
                    }
                }
            }

            LessonStepPhase.SAFE_BREAK -> {
                voiceEngine.speak("Aaj ka learning time complete ho gaya! Ab thoda paani piyo aur khel lo!")
            }
        }
    }

    private fun moveToInteractiveOrQuiz() {
        val topic = _lessonState.value.topic
        if (topic.questions.isNotEmpty()) {
            _lessonState.update {
                it.copy(phase = LessonStepPhase.VOICE_QUESTION, currentQuestionIndex = 0)
            }
            runCurrentLessonPhase()
        } else if (topic.drawingMode != DrawingMode.NONE) {
            _lessonState.update { it.copy(phase = LessonStepPhase.DRAWING_STUDIO) }
            runCurrentLessonPhase()
        } else {
            enterRevisionPhase()
        }
    }

    private fun enterRevisionPhase() {
        _lessonState.update { it.copy(phase = LessonStepPhase.SHORT_REVISION) }
        runCurrentLessonPhase()
    }

    fun skipToNextExplainItem() {
        lessonPhaseJob?.cancel()
        val state = _lessonState.value
        val nextIdx = state.currentItemIndex + 1
        if (nextIdx < state.topic.items.size) {
            _lessonState.update {
                it.copy(phase = LessonStepPhase.COLORFUL_EXPLAIN, currentItemIndex = nextIdx)
            }
            runCurrentLessonPhase()
        } else {
            moveToInteractiveOrQuiz()
        }
    }

    fun triggerInteractivePulse() {
        voiceEngine.playTapPop()
        val item = _lessonState.value.topic.items.getOrNull(_lessonState.value.currentItemIndex)
        _lessonState.update { it.copy(examplePulseCount = it.examplePulseCount + 1) }
        if (item != null) {
            voiceEngine.speak(item.phonicsText, caption = item.title)
        }
    }

    fun submitAnswerOption(optionId: String) {
        val state = _lessonState.value
        val question = state.topic.questions.getOrNull(state.currentQuestionIndex) ?: return
        if (state.phase != LessonStepPhase.VOICE_QUESTION && state.phase != LessonStepPhase.GENTLE_RETRY) return

        if (optionId == question.correctOptionId) {
            _lessonState.update {
                it.copy(
                    phase = LessonStepPhase.CELEBRATE_CORRECT,
                    starsEarnedThisLesson = it.starsEarnedThisLesson + 2,
                    correctCount = it.correctCount + 1,
                    attemptedCount = it.attemptedCount + 1,
                    selectedWrongOptionId = null
                )
            }
            runCurrentLessonPhase()
        } else {
            _lessonState.update {
                it.copy(
                    phase = LessonStepPhase.GENTLE_RETRY,
                    attemptedCount = it.attemptedCount + 1,
                    selectedWrongOptionId = optionId
                )
            }
            runCurrentLessonPhase()
        }
    }

    fun startVoiceAnswerForQuestion() {
        val state = _lessonState.value
        val question = state.topic.questions.getOrNull(state.currentQuestionIndex) ?: return
        voiceEngine.startListening(
            onResult = { spokenText ->
                val normalized = spokenText.lowercase().trim()
                _lessonState.update { it.copy(lastSpokenAnswer = spokenText) }
                val matchedOption = question.options.firstOrNull { opt ->
                    opt.spokenKeywords.any { kw -> normalized.contains(kw.lowercase()) } ||
                        normalized.contains(opt.label.lowercase())
                }
                if (matchedOption != null) {
                    submitAnswerOption(matchedOption.id)
                } else {
                    _lessonState.update {
                        it.copy(micFeedback = "Aapne bola: \"$spokenText\" — Picture par tap karke bhi bata sakte ho!")
                    }
                    voiceEngine.speak("Aapne bola $spokenText! Ab neeche sahi picture par tap karo!")
                }
            },
            onUnavailableOrError = { msg ->
                _lessonState.update { it.copy(micFeedback = msg) }
                voiceEngine.speak(msg)
            }
        )
    }

    fun completeDrawingActivity() {
        voiceEngine.playCelebrateFanfare()
        _lessonState.update {
            it.copy(
                starsEarnedThisLesson = it.starsEarnedThisLesson + 3,
                correctCount = it.correctCount + 1,
                attemptedCount = it.attemptedCount + 1,
                tracingCompletedCount = it.tracingCompletedCount + 1
            )
        }
        enterRevisionPhase()
    }

    private fun completeTopicAndPrepareNext() {
        val state = _lessonState.value
        val totalStars = (state.starsEarnedThisLesson + 2).coerceAtLeast(3)
        val durationSec = ((System.currentTimeMillis() - state.sessionStartTimeMillis) / 1000L)
            .toInt().coerceAtLeast(15)

        viewModelScope.launch {
            repository.recordLessonCompletion(
                topic = state.topic,
                starsEarned = totalStars,
                correctAnswers = state.correctCount.coerceAtLeast(1),
                totalQuestions = state.attemptedCount.coerceAtLeast(1),
                durationSeconds = durationSec
            )
        }

        if (_isSessionLimitReached.value) {
            _lessonState.update {
                it.copy(
                    starsEarnedThisLesson = totalStars,
                    phase = LessonStepPhase.SAFE_BREAK
                )
            }
            runCurrentLessonPhase()
        } else {
            _lessonState.update {
                it.copy(
                    starsEarnedThisLesson = totalStars,
                    phase = LessonStepPhase.TOPIC_COMPLETE,
                    autoAdvanceCountdown = 4
                )
            }
            voiceEngine.playCelebrateFanfare()
            voiceEngine.speak("Shabaash! Topic poora hua! Aapko mile $totalStars stars! Ab agla topic shuru hoga!")
            runCurrentLessonPhase()
        }
    }

    // ==================== GAMES, RHYMES & FLASHCARDS ====================

    fun playRhyme(lyrics: List<String>, notes: List<Pair<Float, Int>>, title: String, onFinished: () -> Unit) {
        voiceEngine.stopSpeaking()
        voiceEngine.speak("Chalo gaate hain: $title!") {
            voiceEngine.playRhymeMelody(notes, lyrics.size) {
                viewModelScope.launch {
                    repository.awardBonusStars(1, "Sang $title", "GAMES")
                }
                onFinished()
            }
        }
    }

    fun stopRhyme() {
        voiceEngine.stopRhyme()
        voiceEngine.stopSpeaking()
    }

    fun awardGameStars(stars: Int, activityTitle: String) {
        voiceEngine.playCelebrateFanfare()
        viewModelScope.launch {
            repository.awardBonusStars(stars, activityTitle, "GAMES")
        }
    }

    // ==================== PARENT SETTINGS ====================

    fun updateChildProfile(name: String, avatar: String, dailyGoal: Int) {
        viewModelScope.launch {
            repository.updateChildProfile(name, avatar, dailyGoal)
        }
    }

    fun setSessionLimitMinutes(minutes: Int) {
        viewModelScope.launch { repository.setSessionLimitMinutes(minutes) }
    }

    fun resetTodayTimer() {
        viewModelScope.launch {
            repository.resetTodayTimer()
            _isSessionLimitReached.value = false
        }
    }

    fun setAutoplayEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setAutoplayEnabled(enabled) }
    }

    fun setVoiceTeacherEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setVoiceTeacherEnabled(enabled) }
    }

    fun setSoundEffectsEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setSoundEffectsEnabled(enabled) }
    }

    fun setSpeechRate(rate: Float) {
        viewModelScope.launch { repository.setSpeechRate(rate) }
    }

    fun setExitProtectionEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setExitProtectionEnabled(enabled) }
    }

    fun updateParentPin(pin: String) {
        viewModelScope.launch { repository.updatePin(pin) }
    }

    fun resetAllProgress() {
        viewModelScope.launch { repository.resetProgress() }
    }

    fun unlockFromBreakScreen() {
        resetTodayTimer()
    }

    fun subjectProgress(subjectId: SubjectId): Float {
        val topics = LkgCurriculumRepository.topicsForSubject(subjectId)
        if (topics.isEmpty()) return 0f
        val completedIds = topicProgressList.value.filter { it.completionsCount > 0 }.map { it.topicId }.toSet()
        val done = topics.count { it.id in completedIds }
        return done.toFloat() / topics.size.toFloat()
    }

    override fun onCleared() {
        super.onCleared()
        voiceEngine.release()
    }
}
