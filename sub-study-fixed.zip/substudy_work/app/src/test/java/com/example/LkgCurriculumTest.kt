package com.example

import com.example.data.model.LkgCurriculumRepository
import com.example.data.model.SubjectId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LkgCurriculumTest {

    @Test
    fun allFiveLkgSubjectsHaveTopics() {
        SubjectId.entries.forEach { subject ->
            val topics = LkgCurriculumRepository.topicsForSubject(subject)
            assertTrue("Expected topics for ${subject.title}", topics.isNotEmpty())
        }
    }

    @Test
    fun nextTopicWrapsAroundCleanly() {
        val last = LkgCurriculumRepository.allTopics.last()
        val next = LkgCurriculumRepository.nextTopicAfter(last.id)
        assertEquals(LkgCurriculumRepository.allTopics.first().id, next.id)
    }

    @Test
    fun allQuestionsHaveValidCorrectOption() {
        LkgCurriculumRepository.allTopics.forEach { topic ->
            topic.questions.forEach { question ->
                val match = question.options.firstOrNull { it.id == question.correctOptionId }
                assertNotNull("Missing correct option for ${question.id}", match)
            }
        }
    }
}
